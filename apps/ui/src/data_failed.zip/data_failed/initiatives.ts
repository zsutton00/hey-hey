/**
 * Initiative Data Layer - Public API
 *
 * This file serves as the main entry point for all initiative-related data operations.
 * It exposes only the hooks and utilities that components need to consume.
 *
 * Internal organization:
 * - src/data/core/ - Query keys, types, and core definitions
 * - src/data/hooks/ - React hooks for queries, mutations, and cache sync
 * - src/data/utils/ - Utility functions for cache management and WebSocket integration
 */

// Export enhanced query hooks with auto-WebSocket integration
export {
  useInitiative,
  useInitiatives,
  useInitiativeConversation,
  type EnhancedUseInitiativeOptions,
  type EnhancedUseInitiativesOptions,
} from "./hooks/useInitiativeQueries";

// Export mutation hooks
export {
  useCreateInitiative,
  useUpdateInitiative,
  useDeleteInitiative,
  useUpdateInitiativeContentByConversation,
} from "./hooks/useInitiativeMutations";

// Export cache synchronization hooks
export {
  useInitiativeCacheSync,
  useInitiativeSpecificCacheSync,
  useOrganizationInitiativesCacheSync,
} from "./hooks/useInitiativeCacheSync";

// Export core types for components that need them
export type {
  UseInitiativeOptions,
  UseInitiativesOptions,
  UseInitiativeConversationsOptions,
  CreateInitiativeMutationOptions,
  UpdateInitiativeMutationOptions,
  DeleteInitiativeMutationOptions,
  UpdateInitiativeContentByConversationOptions,
} from "./core/initiatives";

// Export query keys for advanced use cases (testing, manual cache management)
export { initiativeKeys } from "./core/initiatives";

// Export enhanced cache utilities with conflict resolution
export {
  invalidateAllInitiativeCache,
  invalidateInitiativeCache,
  invalidateInitiativeListsCache,
  handleInitiativeWebSocketUpdate,
  handleInitiativeWebSocketCreation,
  handleInitiativeWebSocketDeletion,
  handleInitiativeWebSocketUpdateWithConflictResolution,
  deferUpdateDuringMutations,
  mergeWithOptimisticUpdates,
  type ConflictResolutionOptions,
} from "./utils/cacheUtils";

// Export additional initiative hooks
export {
  useInitiativeData,
  useConversationInitiatives,
  type UseInitiativeDataParams,
  type UseInitiativeDataReturn,
  type UseConversationInitiativesParams,
  type UseConversationInitiativesReturn,
} from "./hooks/useInitiativeData";

export {
  useInitiativeSave,
  type UseInitiativeSaveProps,
  type UseInitiativeSaveReturn,
} from "./hooks/useInitiativeSave";

export {
  useInitiativeAutosave,
  type UseInitiativeAutosaveProps,
  type UseInitiativeAutosaveReturn,
} from "./hooks/useInitiativeAutosave";

export {
  useInitiativeWebSocket,
  type UseInitiativeWebSocketConfig,
} from "./hooks/useInitiativeWebSocket";

export {
  useInitiativeEditHistory,
  type UseInitiativeEditHistoryParams,
  type UseInitiativeEditHistoryReturn,
} from "./hooks/useInitiativeEditHistory";

export {
  useInitiativeReveal,
  type UseInitiativeRevealProps,
  type UseInitiativeRevealReturn,
} from "./hooks/useInitiativeReveal";

// Export WebSocket management utilities
export {
  subscriptionManager,
  type SubscriptionStats,
  type WebSocketEvent,
} from "./websockets/manager";

// Export WebSocket debug utilities
export {
  useWebSocketDebug,
  webSocketDebugger,
  type WebSocketDebugState,
  type WebSocketEventFilter,
} from "./websockets/debug";
