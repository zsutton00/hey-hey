# Data Integration System Documentation

## Overview

This system provides a unified data layer that integrates React Query (TanStack Query) with WebSocket real-time updates to create a single source of truth for application data. The system is designed around the concept of **cache sync** - automatically synchronizing local cache with real-time server updates via WebSockets.

## Architecture

### Core Components

```
┌─────────────────────┐    ┌─────────────────────┐    ┌─────────────────────┐
│   React Components  │    │   Custom Hooks      │    │   Platform Client   │
│                     │    │                     │    │                     │
│ - useInitiatives    │◄───┤ - useInitiative*    │◄───┤ - API calls         │
│ - useInitiative     │    │ - Cache Sync Hooks  │    │ - HTTP requests     │
│ - Mutations         │    │                     │    │                     │
└─────────────────────┘    └─────────────────────┘    └─────────────────────┘
           │                          │                          │
           ▼                          ▼                          │
┌─────────────────────┐    ┌─────────────────────┐              │
│   React Query       │    │   WebSocket         │              │
│                     │    │   Integration       │              │
│ - Query cache       │◄───┤                     │              │
│ - Mutations         │    │ - Real-time sync    │              │
│ - Invalidation      │    │ - Event handling    │              │
└─────────────────────┘    └─────────────────────┘              │
                                     │                          │
                                     ▼                          │
                           ┌─────────────────────┐              │
                           │   WebSocket Service │◄─────────────┘
                           │                     │
                           │ - Connection mgmt   │
                           │ - Subscription mgmt │
                           │ - Event routing     │
                           └─────────────────────┘
```

### Key Principles

1. **Single Source of Truth**: React Query cache serves as the authoritative data store
2. **Real-time Sync**: WebSocket events automatically update the cache
3. **Optimistic Updates**: UI updates immediately, with rollback on failure
4. **Memory Safety**: Proper cleanup of event handlers and subscriptions
5. **Error Boundaries**: Graceful handling of network and data errors

## File Structure

```
src/data/
├── README.md                           # This documentation
├── initiatives.ts                      # Main export barrel
├── hooks/
│   ├── useInitiativeQueries.ts        # Query hooks (GET operations)
│   ├── useInitiativeMutations.ts      # Mutation hooks (CREATE/UPDATE/DELETE)
│   ├── useInitiativeSave.ts           # Auto-save functionality
│   ├── useInitiativeCacheSync.ts      # WebSocket cache synchronization
│   └── useInitiativeWebSocket.ts      # WebSocket connection management
├── utils/
│   └── cacheUtils.ts                  # Cache manipulation utilities
├── websockets/
│   ├── manager.ts                     # WebSocket subscription manager
│   └── debug.ts                       # Debug utilities
└── __tests__/                         # Test files
```

## Core Concepts

### 1. Query Hooks (Data Fetching)

Query hooks handle all GET operations and provide cached data to components:

```typescript
// Single entity
const {
  data: initiative,
  isLoading,
  error,
} = useInitiative(orgId, initiativeId);

// List of entities
const {
  data: initiatives,
  isLoading,
  error,
} = useInitiatives(orgId, {
  filters: { status: "active" },
});

// Related entity
const { data: conversation } = useInitiativeConversation(
  orgId,
  projectId,
  conversationId
);
```

**Key Features:**

- Automatic caching with configurable TTL
- Background refetching and synchronization
- Loading and error states
- Conditional fetching based on parameters
- Query invalidation on related mutations

### 2. Mutation Hooks (Data Modification)

Mutation hooks handle CREATE/UPDATE/DELETE operations with optimistic updates:

```typescript
const createInitiative = useCreateInitiative();
const updateInitiative = useUpdateInitiative();
const deleteInitiative = useDeleteInitiative();

// Usage with optimistic updates
updateInitiative.mutate(
  { orgId, initiativeId, data: updateData },
  {
    onSuccess: (data) => {
      // Handle success
    },
    onError: (error) => {
      // Handle error (rollback is automatic)
    },
  }
);
```

**Key Features:**

- Optimistic updates with automatic rollback on error
- Cache invalidation for related queries
- Error handling and retry logic
- Loading states during mutations

### 3. Cache Synchronization

The cache sync system keeps local data in sync with server changes via WebSockets:

```typescript
// Enable WebSocket sync for an organization's initiatives
useOrganizationInitiativesCacheSync(orgId, projectId, true);
```

**How it works:**

1. Hook subscribes to WebSocket events for specific entities
2. Server sends real-time updates (created, updated, deleted, status changed)
3. Local cache is automatically updated with new data
4. Components re-render with fresh data instantly

### 4. WebSocket Event Flow

```
Server Event → WebSocket Service → Subscription Manager → Event Handler → Cache Update → Component Re-render
```

**Event Types:**

- `initiative:created` - New initiative added
- `initiative:updated` - Initiative modified
- `initiative:deleted` - Initiative removed
- `initiative:status_changed` - Status transition
- `conversation:updated` - Related conversation changed
- `system:notification` - System-wide notifications

## Adding a New Entity Type

Follow this step-by-step guide to add a new entity type (e.g., "Projects") to the system:

### Step 1: Define TypeScript Types

Create or update type definitions in your API types:

```typescript
// In src/api/types.ts or generated types
export interface ProjectResponseDto {
  id: string;
  name: string;
  description: string;
  organizationId: string;
  status: "ACTIVE" | "INACTIVE" | "ARCHIVED";
  createdAt: string;
  updatedAt: string;
}

export interface CreateProjectDto {
  name: string;
  description: string;
  status: "ACTIVE" | "INACTIVE";
}

export interface UpdateProjectDto {
  name?: string;
  description?: string;
  status?: "ACTIVE" | "INACTIVE" | "ARCHIVED";
}
```

### Step 2: Add Platform Client Methods

Ensure your platform client has the necessary API methods:

```typescript
// In platform client or service layer
class PlatformClient {
  async getProject(
    orgId: string,
    projectId: string
  ): Promise<ApiResponse<ProjectResponseDto>> {
    return this.http.get(`/organizations/${orgId}/projects/${projectId}`);
  }

  async getOrganizationProjects(
    orgId: string
  ): Promise<ApiResponse<ProjectResponseDto[]>> {
    return this.http.get(`/organizations/${orgId}/projects`);
  }

  async createProject(
    orgId: string,
    data: CreateProjectDto
  ): Promise<ApiResponse<ProjectResponseDto>> {
    return this.http.post(`/organizations/${orgId}/projects`, data);
  }

  async updateProject(
    orgId: string,
    projectId: string,
    data: UpdateProjectDto
  ): Promise<ApiResponse<ProjectResponseDto>> {
    return this.http.patch(
      `/organizations/${orgId}/projects/${projectId}`,
      data
    );
  }

  async deleteProject(orgId: string, projectId: string): Promise<void> {
    return this.http.delete(`/organizations/${orgId}/projects/${projectId}`);
  }
}
```

### Step 3: Create Query Hooks

Create `src/data/hooks/useProjectQueries.ts`:

```typescript
import { useQuery, type UseQueryOptions } from "@tanstack/react-query";
import { platformClient } from "../../clients/serviceClients";
import type { ProjectResponseDto } from "../../api";

// Query keys factory
export const projectKeys = {
  all: ["projects"] as const,
  lists: () => [...projectKeys.all, "list"] as const,
  list: (orgId: string, filters?: Record<string, unknown>) =>
    [...projectKeys.lists(), orgId, filters] as const,
  details: () => [...projectKeys.all, "detail"] as const,
  detail: (orgId: string, projectId: string) =>
    [...projectKeys.details(), orgId, projectId] as const,
};

// Single project query
export const useProject = (
  orgId: string,
  projectId: string,
  options?: UseQueryOptions<ProjectResponseDto>
) => {
  return useQuery({
    queryKey: projectKeys.detail(orgId, projectId),
    queryFn: async () => {
      const response = await platformClient.getProject(orgId, projectId);
      return response.data.data;
    },
    enabled: !!(orgId && projectId),
    ...options,
  });
};

// Projects list query
export const useProjects = (
  orgId: string,
  options?: {
    filters?: Record<string, unknown>;
    enabled?: boolean;
  }
) => {
  return useQuery({
    queryKey: projectKeys.list(orgId, options?.filters),
    queryFn: async () => {
      const response = await platformClient.getOrganizationProjects(orgId);
      return response.data.data;
    },
    enabled: options?.enabled !== false && !!orgId,
  });
};
```

### Step 4: Create Mutation Hooks

Create `src/data/hooks/useProjectMutations.ts`:

```typescript
import {
  useMutation,
  useQueryClient,
  type UseMutationOptions,
} from "@tanstack/react-query";
import { platformClient } from "../../clients/serviceClients";
import { projectKeys } from "./useProjectQueries";
import type {
  ProjectResponseDto,
  CreateProjectDto,
  UpdateProjectDto,
} from "../../api";

// Create project mutation
export const useCreateProject = (
  options?: UseMutationOptions<
    ProjectResponseDto,
    Error,
    { orgId: string; data: CreateProjectDto }
  >
) => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ orgId, data }) => {
      const response = await platformClient.createProject(orgId, data);
      return response.data.data;
    },
    onSuccess: (newProject, { orgId }) => {
      // Add to detail cache
      queryClient.setQueryData(
        projectKeys.detail(orgId, newProject.id),
        newProject
      );

      // Invalidate lists to trigger refetch
      queryClient.invalidateQueries({ queryKey: projectKeys.lists() });
    },
    ...options,
  });
};

// Update project mutation
export const useUpdateProject = (
  options?: UseMutationOptions<
    ProjectResponseDto,
    Error,
    { orgId: string; projectId: string; data: UpdateProjectDto }
  >
) => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ orgId, projectId, data }) => {
      const response = await platformClient.updateProject(
        orgId,
        projectId,
        data
      );
      return response.data.data;
    },
    // Optimistic update
    onMutate: async ({ orgId, projectId, data }) => {
      const queryKey = projectKeys.detail(orgId, projectId);
      await queryClient.cancelQueries({ queryKey });

      const previousProject =
        queryClient.getQueryData<ProjectResponseDto>(queryKey);

      if (previousProject) {
        queryClient.setQueryData(queryKey, { ...previousProject, ...data });
      }

      return { previousProject };
    },
    // On success, update with server response
    onSuccess: (updatedProject, { orgId, projectId }) => {
      queryClient.setQueryData(
        projectKeys.detail(orgId, projectId),
        updatedProject
      );
      queryClient.invalidateQueries({ queryKey: projectKeys.lists() });
    },
    // On error, rollback optimistic update
    onError: (_error, { orgId, projectId }, context) => {
      if (context?.previousProject) {
        queryClient.setQueryData(
          projectKeys.detail(orgId, projectId),
          context.previousProject
        );
      }
    },
    ...options,
  });
};

// Delete project mutation
export const useDeleteProject = (
  options?: UseMutationOptions<
    void,
    Error,
    { orgId: string; projectId: string }
  >
) => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ orgId, projectId }) => {
      await platformClient.deleteProject(orgId, projectId);
    },
    onSuccess: (_, { orgId, projectId }) => {
      // Remove from detail cache
      queryClient.removeQueries({
        queryKey: projectKeys.detail(orgId, projectId),
      });
      // Invalidate lists
      queryClient.invalidateQueries({ queryKey: projectKeys.lists() });
    },
    ...options,
  });
};
```

### Step 5: Add WebSocket Cache Sync

Create `src/data/hooks/useProjectCacheSync.ts`:

```typescript
import { useQueryClient } from "@tanstack/react-query";
import { useWebSocketService } from "../../hooks/useWebSocketService";
import { useAuth } from "../../contexts/AuthContext";
import { projectKeys } from "./useProjectQueries";
import { deferCacheUpdate } from "../utils/cacheUtils";
import type { ProjectResponseDto } from "../../api";

export const useOrganizationProjectsCacheSync = (
  orgId: string,
  enabled = true
) => {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  return useWebSocketService({
    userId: user?.id ?? "",
    organizationId: orgId,
    projectIds: [], // Add project IDs if needed for more specific subscriptions
    conversationIds: [],
    initiativeIds: [],
    autoConnect: enabled && !!user?.id && !!orgId,
    events: {
      // Handle project creation
      onProjectCreated: async (event: { project: ProjectResponseDto }) => {
        const { project } = event;

        // Add to detail cache
        queryClient.setQueryData(
          projectKeys.detail(orgId, project.id),
          project
        );

        // Invalidate list queries with cache update deferral
        await deferCacheUpdate(queryClient, () => {
          queryClient.invalidateQueries({ queryKey: projectKeys.lists() });
        });
      },

      // Handle project updates
      onProjectUpdated: async (event: { project: ProjectResponseDto }) => {
        const { project } = event;

        // Update detail cache
        queryClient.setQueryData(
          projectKeys.detail(orgId, project.id),
          project
        );

        // Update any list caches that contain this project
        await deferCacheUpdate(queryClient, () => {
          queryClient.invalidateQueries({ queryKey: projectKeys.lists() });
        });
      },

      // Handle project status changes
      onProjectStatusChanged: async (event: {
        projectId: string;
        status: string;
        project: ProjectResponseDto;
      }) => {
        const { project } = event;

        queryClient.setQueryData(
          projectKeys.detail(orgId, project.id),
          project
        );

        await deferCacheUpdate(queryClient, () => {
          queryClient.invalidateQueries({ queryKey: projectKeys.lists() });
        });
      },

      // Handle project deletion
      onProjectDeleted: async (event: { projectId: string }) => {
        const { projectId } = event;

        // Remove from detail cache
        queryClient.removeQueries({
          queryKey: projectKeys.detail(orgId, projectId),
        });

        // Invalidate list queries
        await deferCacheUpdate(queryClient, () => {
          queryClient.invalidateQueries({ queryKey: projectKeys.lists() });
        });
      },

      // Handle system notifications
      onSystemNotification: async (event: {
        message: string;
        type: string;
      }) => {
        console.info("System notification:", event);
        // Handle notifications as needed
      },
    },
  });
};
```

### Step 6: Create Main Export File

Create `src/data/projects.ts`:

```typescript
// Export all project-related hooks and utilities
export * from "./hooks/useProjectQueries";
export * from "./hooks/useProjectMutations";
export * from "./hooks/useProjectCacheSync";
export { projectKeys } from "./hooks/useProjectQueries";
```

### Step 7: Add WebSocket Event Types

Update your WebSocket service to handle new event types:

```typescript
// In src/services/webSocketService.ts or equivalent
interface WebSocketEvents {
  // Existing events...
  onInitiativeCreated?: (event: {
    initiative: InitiativeResponseDto;
  }) => Promise<void>;
  onInitiativeUpdated?: (event: {
    initiative: InitiativeResponseDto;
  }) => Promise<void>;

  // New project events
  onProjectCreated?: (event: { project: ProjectResponseDto }) => Promise<void>;
  onProjectUpdated?: (event: { project: ProjectResponseDto }) => Promise<void>;
  onProjectStatusChanged?: (event: {
    projectId: string;
    status: string;
    project: ProjectResponseDto;
  }) => Promise<void>;
  onProjectDeleted?: (event: { projectId: string }) => Promise<void>;

  // System events
  onSystemNotification?: (event: {
    message: string;
    type: string;
  }) => Promise<void>;
}
```

### Step 8: Write Tests

Create test files following the existing patterns:

```typescript
// src/data/__tests__/project-queries.test.tsx
describe("useProject", () => {
  test("fetches project successfully", async () => {
    // Test implementation following existing patterns
  });

  test("handles loading state", () => {
    // Test implementation
  });

  test("handles error state", async () => {
    // Test implementation
  });
});
```

### Step 9: Usage in Components

Use the new entity type in your React components:

```typescript
import React from "react";
import {
  useProjects,
  useProject,
  useCreateProject,
  useUpdateProject,
  useOrganizationProjectsCacheSync,
} from "../data/projects";

export const ProjectsPage: React.FC = () => {
  const orgId = "org-123";

  // Enable real-time sync
  useOrganizationProjectsCacheSync(orgId);

  // Fetch data
  const { data: projects, isLoading } = useProjects(orgId);
  const createProject = useCreateProject();

  const handleCreateProject = () => {
    createProject.mutate({
      orgId,
      data: {
        name: "New Project",
        description: "Project description",
        status: "ACTIVE",
      },
    });
  };

  return <div>{/* Your component JSX */}</div>;
};
```

## Best Practices

### Query Key Management

- Use factory functions for consistent query keys
- Include all relevant parameters in query keys
- Use hierarchical key structures for easy invalidation

### Error Handling

- Always handle loading and error states in components
- Use optimistic updates with proper rollback on failure
- Log errors appropriately for debugging

### Memory Management

- WebSocket subscriptions are automatically cleaned up
- Query cache is managed by React Query
- Always use the provided cache sync hooks to avoid memory leaks

### Performance

- Use `enabled` option to conditionally fetch data
- Implement proper query invalidation strategies
- Consider using `suspense` mode for loading states

### Testing

- Mock all external dependencies (API calls, WebSocket service)
- Test both success and error scenarios
- Verify cache updates and optimistic updates work correctly

## Troubleshooting

### Common Issues

1. **Cache not updating from WebSocket events**

   - Verify WebSocket connection is established
   - Check event handler registration
   - Ensure query keys match between queries and cache updates

2. **Memory leaks**

   - Use the provided cache sync hooks
   - Don't manually register WebSocket event handlers
   - Ensure components are properly unmounted

3. **Race conditions**

   - Use the `deferCacheUpdate` utility for cache invalidation
   - Don't perform immediate cache updates in mutation success handlers
   - Use optimistic updates properly with rollback

4. **Type errors**
   - Ensure all API types are properly defined
   - Use proper generic typing for mutations and queries
   - Run `pnpm run type-check` regularly

### Debug Tools

Use the provided debug utilities:

```typescript
import { getWebSocketDebugInfo, clearEventLog } from "../data/websockets/debug";

// Get current connection status and event log
const debugInfo = getWebSocketDebugInfo();
console.log("WebSocket Debug Info:", debugInfo);

// Clear event log (keeps subscriptions active)
clearEventLog();
```

## Migration Guide

If migrating existing entity handling to this system:

1. **Audit existing data fetching**: Identify all API calls and state management
2. **Replace with query hooks**: Convert to React Query patterns
3. **Add WebSocket integration**: Implement cache sync hooks
4. **Update error handling**: Use consistent error handling patterns
5. **Add optimistic updates**: Improve user experience with immediate feedback
6. **Test thoroughly**: Ensure all functionality works with new system

## Future Enhancements

- **Offline support**: Cache data for offline access
- **Pagination**: Built-in pagination support for large datasets
- **Real-time collaboration**: Conflict resolution for simultaneous edits
- **Advanced caching**: More sophisticated cache invalidation strategies
- **Performance monitoring**: Built-in performance metrics and monitoring

---

This system provides a robust, type-safe, and performant foundation for real-time data management in React applications. Follow the patterns outlined above to maintain consistency and reliability across your application.
