/**
 * Tests for Cache Strategy Atoms
 * 
 * Tests the cache strategy system that determines how WebSocket events
 * should update the TanStack Query cache through Jotai atoms.
 */

import { describe, it, expect, beforeEach } from 'vitest';
import { createStore } from 'jotai';
import {
  type CacheStrategy,
  defaultCacheStrategyAtom,
  entityCacheStrategyAtom,
  getCacheStrategyAtom,
} from '../cacheStrategyAtoms';

describe('cacheStrategyAtoms', () => {
  let store: ReturnType<typeof createStore>;

  beforeEach(() => {
    store = createStore();
  });

  describe('defaultCacheStrategyAtom', () => {
    it('should have REFRESH_AFTER_SET as default strategy', () => {
      const strategy = store.get(defaultCacheStrategyAtom);
      expect(strategy).toBe('REFRESH_AFTER_SET');
    });

    it('should allow setting a new default strategy', () => {
      store.set(defaultCacheStrategyAtom, 'INVALIDATE');
      const strategy = store.get(defaultCacheStrategyAtom);
      expect(strategy).toBe('INVALIDATE');
    });

    it('should allow all valid cache strategies', () => {
      const validStrategies: CacheStrategy[] = ['INVALIDATE', 'MERGE', 'REFRESH_AFTER_SET'];
      
      validStrategies.forEach(strategy => {
        store.set(defaultCacheStrategyAtom, strategy);
        const result = store.get(defaultCacheStrategyAtom);
        expect(result).toBe(strategy);
      });
    });
  });

  describe('entityCacheStrategyAtom', () => {
    it('should start with empty entity strategies', () => {
      const strategies = store.get(entityCacheStrategyAtom);
      expect(strategies).toEqual({});
    });

    it('should allow setting entity-specific strategies', () => {
      const entityStrategies = {
        'initiative:init-123': 'MERGE' as CacheStrategy,
        'conversation:conv-456': 'INVALIDATE' as CacheStrategy,
      };

      store.set(entityCacheStrategyAtom, entityStrategies);
      const result = store.get(entityCacheStrategyAtom);
      
      expect(result).toEqual(entityStrategies);
    });

    it('should persist entity strategies across reads', () => {
      const entityStrategies = {
        'initiative:init-789': 'REFRESH_AFTER_SET' as CacheStrategy,
      };

      store.set(entityCacheStrategyAtom, entityStrategies);
      
      // Read multiple times to ensure persistence
      const read1 = store.get(entityCacheStrategyAtom);
      const read2 = store.get(entityCacheStrategyAtom);
      
      expect(read1).toEqual(entityStrategies);
      expect(read2).toEqual(entityStrategies);
    });

    it('should allow updating individual entity strategies', () => {
      // Set initial strategies
      store.set(entityCacheStrategyAtom, {
        'initiative:init-1': 'MERGE' as CacheStrategy,
        'initiative:init-2': 'INVALIDATE' as CacheStrategy,
      });

      // Update with additional strategy
      const current = store.get(entityCacheStrategyAtom);
      store.set(entityCacheStrategyAtom, {
        ...current,
        'initiative:init-3': 'REFRESH_AFTER_SET' as CacheStrategy,
      });

      const result = store.get(entityCacheStrategyAtom);
      expect(result).toEqual({
        'initiative:init-1': 'MERGE',
        'initiative:init-2': 'INVALIDATE',
        'initiative:init-3': 'REFRESH_AFTER_SET',
      });
    });

    it('should allow removing entity strategies', () => {
      // Set initial strategies
      store.set(entityCacheStrategyAtom, {
        'initiative:init-1': 'MERGE' as CacheStrategy,
        'initiative:init-2': 'INVALIDATE' as CacheStrategy,
      });

      // Remove one strategy
      const current = store.get(entityCacheStrategyAtom);
      const { 'initiative:init-1': removed, ...remaining } = current;
      store.set(entityCacheStrategyAtom, remaining);

      const result = store.get(entityCacheStrategyAtom);
      expect(result).toEqual({
        'initiative:init-2': 'INVALIDATE',
      });
      expect(result).not.toHaveProperty('initiative:init-1');
    });
  });

  describe('getCacheStrategyAtom', () => {
    it('should return default strategy when no entity-specific strategy exists', () => {
      // Set a custom default
      store.set(defaultCacheStrategyAtom, 'MERGE');
      
      const strategyAtom = getCacheStrategyAtom('initiative', 'init-123');
      const strategy = store.get(strategyAtom);
      
      expect(strategy).toBe('MERGE');
    });

    it('should return entity-specific strategy when it exists', () => {
      // Set default strategy
      store.set(defaultCacheStrategyAtom, 'INVALIDATE');
      
      // Set entity-specific strategy
      store.set(entityCacheStrategyAtom, {
        'initiative:init-123': 'REFRESH_AFTER_SET' as CacheStrategy,
      });
      
      const strategyAtom = getCacheStrategyAtom('initiative', 'init-123');
      const strategy = store.get(strategyAtom);
      
      expect(strategy).toBe('REFRESH_AFTER_SET'); // Entity-specific, not default
    });

    it('should construct correct entity key from type and id', () => {
      store.set(entityCacheStrategyAtom, {
        'conversation:conv-456': 'MERGE' as CacheStrategy,
        'initiative:init-789': 'INVALIDATE' as CacheStrategy,
      });
      
      const conversationStrategyAtom = getCacheStrategyAtom('conversation', 'conv-456');
      const initiativeStrategyAtom = getCacheStrategyAtom('initiative', 'init-789');
      
      expect(store.get(conversationStrategyAtom)).toBe('MERGE');
      expect(store.get(initiativeStrategyAtom)).toBe('INVALIDATE');
    });

    it('should fall back to default when entity key does not match', () => {
      store.set(defaultCacheStrategyAtom, 'REFRESH_AFTER_SET');
      store.set(entityCacheStrategyAtom, {
        'initiative:init-123': 'MERGE' as CacheStrategy,
      });
      
      // Request different entity
      const strategyAtom = getCacheStrategyAtom('initiative', 'init-999');
      const strategy = store.get(strategyAtom);
      
      expect(strategy).toBe('REFRESH_AFTER_SET'); // Falls back to default
    });

    it('should be reactive to changes in entity strategies', () => {
      const strategyAtom = getCacheStrategyAtom('initiative', 'init-123');
      
      // Initially should return default
      store.set(defaultCacheStrategyAtom, 'INVALIDATE');
      expect(store.get(strategyAtom)).toBe('INVALIDATE');
      
      // Add entity-specific strategy
      store.set(entityCacheStrategyAtom, {
        'initiative:init-123': 'MERGE' as CacheStrategy,
      });
      expect(store.get(strategyAtom)).toBe('MERGE');
      
      // Remove entity-specific strategy
      store.set(entityCacheStrategyAtom, {});
      expect(store.get(strategyAtom)).toBe('INVALIDATE'); // Back to default
    });

    it('should be reactive to changes in default strategy', () => {
      const strategyAtom = getCacheStrategyAtom('initiative', 'init-123');
      
      // Set initial default
      store.set(defaultCacheStrategyAtom, 'MERGE');
      expect(store.get(strategyAtom)).toBe('MERGE');
      
      // Change default
      store.set(defaultCacheStrategyAtom, 'REFRESH_AFTER_SET');
      expect(store.get(strategyAtom)).toBe('REFRESH_AFTER_SET');
    });

    it('should handle different entity types correctly', () => {
      store.set(entityCacheStrategyAtom, {
        'initiative:123': 'MERGE' as CacheStrategy,
        'conversation:123': 'INVALIDATE' as CacheStrategy,
        'project:123': 'REFRESH_AFTER_SET' as CacheStrategy,
      });
      
      const initiativeAtom = getCacheStrategyAtom('initiative', '123');
      const conversationAtom = getCacheStrategyAtom('conversation', '123');
      const projectAtom = getCacheStrategyAtom('project', '123');
      
      expect(store.get(initiativeAtom)).toBe('MERGE');
      expect(store.get(conversationAtom)).toBe('INVALIDATE');
      expect(store.get(projectAtom)).toBe('REFRESH_AFTER_SET');
    });
  });

  describe('cache strategy persistence', () => {
    it('should maintain strategy consistency across multiple stores', () => {
      // This test simulates the atomWithStorage behavior
      const entityStrategies = {
        'initiative:init-persistent': 'MERGE' as CacheStrategy,
      };
      
      store.set(entityCacheStrategyAtom, entityStrategies);
      
      // Create a new store (simulating app restart/refresh)
      const newStore = createStore();
      
      // In a real scenario with atomWithStorage, this would be automatically persisted
      // For this test, we manually set it to verify the atom structure works
      newStore.set(entityCacheStrategyAtom, entityStrategies);
      
      const strategyAtom = getCacheStrategyAtom('initiative', 'init-persistent');
      expect(newStore.get(strategyAtom)).toBe('MERGE');
    });
  });

  describe('edge cases and error conditions', () => {
    it('should handle empty entity type and id gracefully', () => {
      const strategyAtom = getCacheStrategyAtom('', '');
      const strategy = store.get(strategyAtom);
      
      // Should fall back to default
      expect(strategy).toBe('REFRESH_AFTER_SET');
    });

    it('should handle special characters in entity type and id', () => {
      const specialStrategies = {
        'initiative-test:init@123#special': 'MERGE' as CacheStrategy,
      };
      
      store.set(entityCacheStrategyAtom, specialStrategies);
      
      const strategyAtom = getCacheStrategyAtom('initiative-test', 'init@123#special');
      const strategy = store.get(strategyAtom);
      
      expect(strategy).toBe('MERGE');
    });

    it('should handle very long entity keys', () => {
      const longKey = 'very-long-entity-type-name-that-exceeds-normal-length';
      const longId = 'very-long-entity-id-' + 'a'.repeat(100);
      const compositeKey = `${longKey}:${longId}`;
      
      store.set(entityCacheStrategyAtom, {
        [compositeKey]: 'INVALIDATE' as CacheStrategy,
      });
      
      const strategyAtom = getCacheStrategyAtom(longKey, longId);
      const strategy = store.get(strategyAtom);
      
      expect(strategy).toBe('INVALIDATE');
    });

    it('should be case-sensitive for entity keys', () => {
      store.set(entityCacheStrategyAtom, {
        'Initiative:init-123': 'MERGE' as CacheStrategy,
        'initiative:init-123': 'INVALIDATE' as CacheStrategy,
      });
      
      const upperCaseAtom = getCacheStrategyAtom('Initiative', 'init-123');
      const lowerCaseAtom = getCacheStrategyAtom('initiative', 'init-123');
      
      expect(store.get(upperCaseAtom)).toBe('MERGE');
      expect(store.get(lowerCaseAtom)).toBe('INVALIDATE');
    });
  });
});