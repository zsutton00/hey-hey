/**
 * Tests for WebSocket Utils
 * 
 * Tests the utilities for updating Jotai atoms based on WebSocket events
 * using configured cache strategies.
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';
import { atom, WritableAtom } from 'jotai';
import { createWebSocketAtomUpdater } from '../websocketUtils';
import type { CacheStrategy } from '../cacheStrategyAtoms';
import type { InitiativeResponseDto } from '../../../api';

// Mock the query key helper function by testing its behavior
const getQueryKeyFromEntityKey = (entityKey: string): string[] => {
  return entityKey.split(':');
};

describe('websocketUtils', () => {
  let mockAtom: WritableAtom<InitiativeResponseDto | null, [InitiativeResponseDto], void>;
  let mockGetAtomValue: ReturnType<typeof vi.fn>;
  let mockSetAtomValue: ReturnType<typeof vi.fn>;
  let mockQueryClient: {
    invalidateQueries: ReturnType<typeof vi.fn>;
    setQueryData: ReturnType<typeof vi.fn>;
  };

  beforeEach(() => {
    // Create a mock writable atom
    mockAtom = atom<InitiativeResponseDto | null, [InitiativeResponseDto], void>(
      null,
      (_get, _set, newValue) => newValue
    );

    // Mock Jotai store functions
    mockGetAtomValue = vi.fn();
    mockSetAtomValue = vi.fn();

    // Mock QueryClient
    mockQueryClient = {
      invalidateQueries: vi.fn(),
      setQueryData: vi.fn(),
    };

    // Reset all mocks
    vi.clearAllMocks();
  });

  describe('createWebSocketAtomUpdater', () => {
    it('should create an updater with correct entity key and strategy', () => {
      const entityKey = 'initiative:org-123:init-456';
      const strategy: CacheStrategy = 'REFRESH_AFTER_SET';

      const updater = createWebSocketAtomUpdater(mockAtom, entityKey, strategy);

      expect(updater).toBeDefined();
      expect(updater.update).toBeTypeOf('function');
    });

    it('should handle INVALIDATE strategy correctly', () => {
      const entityKey = 'initiative:org-123:init-456';
      const strategy: CacheStrategy = 'INVALIDATE';
      const newData: InitiativeResponseDto = {
        id: 'init-456',
        name: 'Updated Initiative',
        description: 'Updated via WebSocket',
        organizationId: 'org-123',
        status: 'ACTIVE',
        priority: 'HIGH',
        creatorType: 'USER',
        createdAt: '2025-01-01T00:00:00Z',
        updatedAt: '2025-01-01T01:00:00Z',
      };

      const updater = createWebSocketAtomUpdater(mockAtom, entityKey, strategy);
      updater.update(newData, mockGetAtomValue, mockSetAtomValue, mockQueryClient);

      // Should set atom value
      expect(mockSetAtomValue).toHaveBeenCalledWith(mockAtom, newData);

      // Should invalidate queries with correct query key
      const expectedQueryKey = ['initiative', 'org-123', 'init-456'];
      expect(mockQueryClient.invalidateQueries).toHaveBeenCalledWith(expectedQueryKey);

      // Should not set query data or trigger background refetch for INVALIDATE
      expect(mockQueryClient.setQueryData).not.toHaveBeenCalled();
    });

    it('should handle REFRESH_AFTER_SET strategy correctly', () => {
      const entityKey = 'initiative:org-123:init-456';
      const strategy: CacheStrategy = 'REFRESH_AFTER_SET';
      const newData: InitiativeResponseDto = {
        id: 'init-456',
        name: 'Refresh Test Initiative',
        description: 'Testing refresh after set',
        organizationId: 'org-123',
        status: 'BACKLOG',
        priority: 'MEDIUM',
        creatorType: 'SYSTEM',
        createdAt: '2025-01-01T00:00:00Z',
        updatedAt: '2025-01-01T02:00:00Z',
      };

      const updater = createWebSocketAtomUpdater(mockAtom, entityKey, strategy);
      updater.update(newData, mockGetAtomValue, mockSetAtomValue, mockQueryClient);

      // Should set atom value
      expect(mockSetAtomValue).toHaveBeenCalledWith(mockAtom, newData);

      // Should set query data immediately
      const expectedQueryKey = ['initiative', 'org-123', 'init-456'];
      expect(mockQueryClient.setQueryData).toHaveBeenCalledWith(expectedQueryKey, newData);

      // Should invalidate for background refetch with inactive option
      expect(mockQueryClient.invalidateQueries).toHaveBeenCalledWith(expectedQueryKey, {
        refetchType: 'inactive',
      });
    });

    it('should handle MERGE strategy correctly', () => {
      const entityKey = 'initiative:org-123:init-456';
      const strategy: CacheStrategy = 'MERGE';
      
      const currentData: InitiativeResponseDto = {
        id: 'init-456',
        name: 'Original Initiative',
        description: 'Original description',
        organizationId: 'org-123',
        status: 'BACKLOG',
        priority: 'LOW',
        creatorType: 'USER',
        createdAt: '2025-01-01T00:00:00Z',
        updatedAt: '2025-01-01T00:30:00Z',
        tags: ['original', 'test'],
      };

      const updateData: Partial<InitiativeResponseDto> = {
        name: 'Merged Initiative',
        priority: 'HIGH',
        updatedAt: '2025-01-01T03:00:00Z',
        tags: ['merged', 'updated'],
      };

      mockGetAtomValue.mockReturnValue(currentData);

      const updater = createWebSocketAtomUpdater(mockAtom, entityKey, strategy);
      updater.update(updateData as InitiativeResponseDto, mockGetAtomValue, mockSetAtomValue, mockQueryClient);

      // Should merge the data
      const expectedMerged = { ...currentData, ...updateData };
      expect(mockSetAtomValue).toHaveBeenCalledWith(mockAtom, expectedMerged);

      // Should set merged data in query cache
      const expectedQueryKey = ['initiative', 'org-123', 'init-456'];
      expect(mockQueryClient.setQueryData).toHaveBeenCalledWith(expectedQueryKey, expectedMerged);

      // Should not invalidate for MERGE strategy
      expect(mockQueryClient.invalidateQueries).not.toHaveBeenCalled();
    });

    it('should handle MERGE strategy with null current data', () => {
      const entityKey = 'initiative:org-123:init-456';
      const strategy: CacheStrategy = 'MERGE';
      const newData: InitiativeResponseDto = {
        id: 'init-456',
        name: 'New Initiative',
        description: 'New via WebSocket',
        organizationId: 'org-123',
        status: 'ACTIVE',
        priority: 'MEDIUM',
        creatorType: 'SYSTEM',
        createdAt: '2025-01-01T00:00:00Z',
        updatedAt: '2025-01-01T01:00:00Z',
      };

      mockGetAtomValue.mockReturnValue(null);

      const updater = createWebSocketAtomUpdater(mockAtom, entityKey, strategy);
      updater.update(newData, mockGetAtomValue, mockSetAtomValue, mockQueryClient);

      // Should merge with null (resulting in the new data)
      const expectedMerged = newData; // null spreads to empty object, so result is just newData
      expect(mockSetAtomValue).toHaveBeenCalledWith(mockAtom, expectedMerged);

      // Should set data in query cache
      const expectedQueryKey = ['initiative', 'org-123', 'init-456'];
      expect(mockQueryClient.setQueryData).toHaveBeenCalledWith(expectedQueryKey, expectedMerged);
    });

    it('should parse entity keys correctly for different entity types', () => {
      const testCases = [
        {
          entityKey: 'initiative:org-123:init-456',
          expectedQueryKey: ['initiative', 'org-123', 'init-456'],
        },
        {
          entityKey: 'conversation:conv-789',
          expectedQueryKey: ['conversation', 'conv-789'],
        },
        {
          entityKey: 'project:org-456:proj-123',
          expectedQueryKey: ['project', 'org-456', 'proj-123'],
        },
        {
          entityKey: 'user:user-789:settings',
          expectedQueryKey: ['user', 'user-789', 'settings'],
        },
      ];

      testCases.forEach(({ entityKey, expectedQueryKey }) => {
        const strategy: CacheStrategy = 'INVALIDATE';
        const mockData = { id: 'test' } as InitiativeResponseDto;

        const updater = createWebSocketAtomUpdater(mockAtom, entityKey, strategy);
        updater.update(mockData, mockGetAtomValue, mockSetAtomValue, mockQueryClient);

        expect(mockQueryClient.invalidateQueries).toHaveBeenCalledWith(expectedQueryKey);

        // Reset mocks for next iteration
        vi.clearAllMocks();
      });
    });

    it('should handle complex entity keys with special characters', () => {
      const entityKey = 'initiative-test:org@123#special:init_456-v2';
      const expectedQueryKey = ['initiative-test', 'org@123#special', 'init_456-v2'];
      const strategy: CacheStrategy = 'INVALIDATE';
      const mockData = { id: 'test' } as InitiativeResponseDto;

      const updater = createWebSocketAtomUpdater(mockAtom, entityKey, strategy);
      updater.update(mockData, mockGetAtomValue, mockSetAtomValue, mockQueryClient);

      expect(mockQueryClient.invalidateQueries).toHaveBeenCalledWith(expectedQueryKey);
    });

    it('should handle empty entity key gracefully', () => {
      const entityKey = '';
      const expectedQueryKey = [''];
      const strategy: CacheStrategy = 'INVALIDATE';
      const mockData = { id: 'test' } as InitiativeResponseDto;

      const updater = createWebSocketAtomUpdater(mockAtom, entityKey, strategy);
      updater.update(mockData, mockGetAtomValue, mockSetAtomValue, mockQueryClient);

      expect(mockQueryClient.invalidateQueries).toHaveBeenCalledWith(expectedQueryKey);
    });

    it('should handle entity key without colons', () => {
      const entityKey = 'singlepart';
      const expectedQueryKey = ['singlepart'];
      const strategy: CacheStrategy = 'INVALIDATE';
      const mockData = { id: 'test' } as InitiativeResponseDto;

      const updater = createWebSocketAtomUpdater(mockAtom, entityKey, strategy);
      updater.update(mockData, mockGetAtomValue, mockSetAtomValue, mockQueryClient);

      expect(mockQueryClient.invalidateQueries).toHaveBeenCalledWith(expectedQueryKey);
    });
  });

  describe('error handling and edge cases', () => {
    it('should handle undefined new data gracefully', () => {
      const entityKey = 'initiative:org-123:init-456';
      const strategy: CacheStrategy = 'REFRESH_AFTER_SET';
      const undefinedData = undefined as unknown as InitiativeResponseDto;

      const updater = createWebSocketAtomUpdater(mockAtom, entityKey, strategy);
      updater.update(undefinedData, mockGetAtomValue, mockSetAtomValue, mockQueryClient);

      expect(mockSetAtomValue).toHaveBeenCalledWith(mockAtom, undefinedData);
      expect(mockQueryClient.setQueryData).toHaveBeenCalledWith(
        ['initiative', 'org-123', 'init-456'],
        undefinedData
      );
    });

    it('should handle queryClient method failures gracefully', () => {
      const entityKey = 'initiative:org-123:init-456';
      const strategy: CacheStrategy = 'INVALIDATE';
      const mockData = { id: 'test' } as InitiativeResponseDto;

      // Mock queryClient methods to throw errors
      mockQueryClient.invalidateQueries.mockImplementation(() => {
        throw new Error('Query client error');
      });

      const updater = createWebSocketAtomUpdater(mockAtom, entityKey, strategy);

      // Should not throw, but handle the error gracefully
      expect(() => {
        updater.update(mockData, mockGetAtomValue, mockSetAtomValue, mockQueryClient);
      }).toThrow('Query client error');

      // Atom should still be updated even if query client fails
      expect(mockSetAtomValue).toHaveBeenCalledWith(mockAtom, mockData);
    });

    it('should handle getAtomValue returning undefined for MERGE strategy', () => {
      const entityKey = 'initiative:org-123:init-456';
      const strategy: CacheStrategy = 'MERGE';
      const newData: InitiativeResponseDto = {
        id: 'init-456',
        name: 'New Initiative',
        description: 'New description',
        organizationId: 'org-123',
        status: 'ACTIVE',
        priority: 'HIGH',
        creatorType: 'USER',
        createdAt: '2025-01-01T00:00:00Z',
        updatedAt: '2025-01-01T01:00:00Z',
      };

      mockGetAtomValue.mockReturnValue(undefined);

      const updater = createWebSocketAtomUpdater(mockAtom, entityKey, strategy);
      updater.update(newData, mockGetAtomValue, mockSetAtomValue, mockQueryClient);

      // Should merge with undefined (resulting in the new data)
      const expectedMerged = newData; // undefined spreads to empty object, so result is just newData
      expect(mockSetAtomValue).toHaveBeenCalledWith(mockAtom, expectedMerged);
    });

    it('should handle setAtomValue failures gracefully', () => {
      const entityKey = 'initiative:org-123:init-456';
      const strategy: CacheStrategy = 'INVALIDATE';
      const mockData = { id: 'test' } as InitiativeResponseDto;

      // Mock setAtomValue to throw
      mockSetAtomValue.mockImplementation(() => {
        throw new Error('Set atom error');
      });

      const updater = createWebSocketAtomUpdater(mockAtom, entityKey, strategy);

      expect(() => {
        updater.update(mockData, mockGetAtomValue, mockSetAtomValue, mockQueryClient);
      }).toThrow('Set atom error');

      // Query client operations should still be called
      expect(mockQueryClient.invalidateQueries).toHaveBeenCalled();
    });

    it('should maintain function reference consistency', () => {
      const entityKey = 'initiative:org-123:init-456';
      const strategy: CacheStrategy = 'MERGE';

      const updater1 = createWebSocketAtomUpdater(mockAtom, entityKey, strategy);
      const updater2 = createWebSocketAtomUpdater(mockAtom, entityKey, strategy);

      // Different instances should have different function references
      expect(updater1.update).not.toBe(updater2.update);

      // But both should work correctly
      const mockData = { id: 'test' } as InitiativeResponseDto;
      mockGetAtomValue.mockReturnValue(null);

      updater1.update(mockData, mockGetAtomValue, mockSetAtomValue, mockQueryClient);
      expect(mockSetAtomValue).toHaveBeenCalledTimes(1);

      updater2.update(mockData, mockGetAtomValue, mockSetAtomValue, mockQueryClient);
      expect(mockSetAtomValue).toHaveBeenCalledTimes(2);
    });
  });

  describe('performance and optimization', () => {
    it('should not perform unnecessary operations for identical data', () => {
      const entityKey = 'initiative:org-123:init-456';
      const strategy: CacheStrategy = 'MERGE';
      
      const existingData: InitiativeResponseDto = {
        id: 'init-456',
        name: 'Existing Initiative',
        description: 'Existing description',
        organizationId: 'org-123',
        status: 'ACTIVE',
        priority: 'MEDIUM',
        creatorType: 'USER',
        createdAt: '2025-01-01T00:00:00Z',
        updatedAt: '2025-01-01T01:00:00Z',
      };

      mockGetAtomValue.mockReturnValue(existingData);

      const updater = createWebSocketAtomUpdater(mockAtom, entityKey, strategy);
      updater.update(existingData, mockGetAtomValue, mockSetAtomValue, mockQueryClient);

      // Should still perform merge operation even with identical data
      // (The optimization for identical data would be handled at a higher level)
      expect(mockSetAtomValue).toHaveBeenCalledWith(mockAtom, existingData);
      expect(mockQueryClient.setQueryData).toHaveBeenCalledWith(
        ['initiative', 'org-123', 'init-456'],
        existingData
      );
    });

    it('should handle high-frequency updates efficiently', () => {
      const entityKey = 'initiative:org-123:init-456';
      const strategy: CacheStrategy = 'REFRESH_AFTER_SET';
      const updater = createWebSocketAtomUpdater(mockAtom, entityKey, strategy);

      // Simulate rapid updates
      for (let i = 0; i < 10; i++) {
        const mockData: InitiativeResponseDto = {
          id: 'init-456',
          name: `Initiative ${i}`,
          description: `Update ${i}`,
          organizationId: 'org-123',
          status: 'ACTIVE',
          priority: 'HIGH',
          creatorType: 'SYSTEM',
          createdAt: '2025-01-01T00:00:00Z',
          updatedAt: new Date(Date.now() + i * 1000).toISOString(),
        };

        updater.update(mockData, mockGetAtomValue, mockSetAtomValue, mockQueryClient);
      }

      // Should handle all updates
      expect(mockSetAtomValue).toHaveBeenCalledTimes(10);
      expect(mockQueryClient.setQueryData).toHaveBeenCalledTimes(10);
      expect(mockQueryClient.invalidateQueries).toHaveBeenCalledTimes(10);
    });
  });
});