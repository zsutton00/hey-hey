/**
 * Initiative Atoms - Combined atomWithQuery + WebSocket Update Capability
 *
 * Combines TanStack Query data fetching with WebSocket update capabilities
 * in a single atom family for clean integration.
 */

import { atom } from "jotai";
import { atomFamily } from "jotai/utils";
import { atomWithQuery } from "jotai-tanstack-query";
import type { InitiativeResponseDto } from "../../api";
import { platformClient } from "../../clients/serviceClients";
import { getCacheStrategyAtom } from "./cacheStrategyAtoms";
import { createWebSocketAtomUpdater } from "./websocketUtils";

// ============================================================================
// SINGLE ENTITY ATOMS
// ============================================================================

/**
 * Combined Initiative Atom Family
 * 
 * Provides both TanStack Query functionality and WebSocket update capability
 * in a single atom. The atom can be read for data and written to for WebSocket updates.
 */
export const initiativeAtomFamily = atomFamily(
  (params: { orgId: string; initiativeId: string }) => {
    // Base atom with TanStack Query integration
    const baseQueryAtom = atomWithQuery(() => ({
      queryKey: ["initiative", params.orgId, params.initiativeId],
      queryFn: async () => {
        const response = await platformClient.getInitiative(
          params.orgId,
          params.initiativeId
        );
        return response.data.data as InitiativeResponseDto;
      },
      enabled: !!params.orgId && !!params.initiativeId,
    }));

    // Enhanced atom that combines query functionality with WebSocket updates
    return atom(
      (get) => get(baseQueryAtom),
      (get, set, update: InitiativeResponseDto) => {
        const strategy = get(
          getCacheStrategyAtom("initiative", params.initiativeId)
        );
        
        // Create updater for WebSocket events
        const updater = createWebSocketAtomUpdater(
          baseQueryAtom,
          `initiative:${params.orgId}:${params.initiativeId}`,
          strategy
        );
        
        // Apply the update using the configured cache strategy
        updater.update(update, get, set, /* queryClient will be passed from WebSocket manager */);
      }
    );
  }
);

// ============================================================================
// LIST ENTITY ATOMS
// ============================================================================

/**
 * Combined Organization Initiatives Atom Family
 * 
 * Provides both TanStack Query functionality for list fetching and 
 * WebSocket update capability for list modifications.
 */
export const organizationInitiativesAtomFamily = atomFamily((orgId: string) => {
  // Base atom with TanStack Query integration
  const baseQueryAtom = atomWithQuery(() => ({
    queryKey: ["initiatives", orgId],
    queryFn: async () => {
      const response = await platformClient.getOrganizationInitiatives(orgId);
      return response.data.data as InitiativeResponseDto[];
    },
    enabled: !!orgId,
  }));

  // Enhanced atom with WebSocket list update capability
  return atom(
    (get) => get(baseQueryAtom),
    (
      get,
      set,
      update: {
        action: "update" | "create" | "delete";
        data: InitiativeResponseDto;
        queryClient: any; // QueryClient will be passed from WebSocket manager
      }
    ) => {
      const strategy = get(getCacheStrategyAtom("initiatives", orgId));
      const currentResult = get(baseQueryAtom);
      const currentList = currentResult.data || [];

      let newList: InitiativeResponseDto[];

      switch (update.action) {
        case "update":
          newList = currentList.map((item) =>
            item.id === update.data.id ? update.data : item
          );
          break;
        case "create":
          newList = [...currentList, update.data];
          break;
        case "delete":
          newList = currentList.filter((item) => item.id !== update.data.id);
          break;
      }

      // Apply cache strategy to the list
      switch (strategy) {
        case "INVALIDATE":
          update.queryClient.invalidateQueries(["initiatives", orgId]);
          break;
        case "REFRESH_AFTER_SET":
          update.queryClient.setQueryData(["initiatives", orgId], newList);
          update.queryClient.invalidateQueries(["initiatives", orgId], {
            refetchType: "inactive",
          });
          break;
        case "MERGE":
          update.queryClient.setQueryData(["initiatives", orgId], newList);
          break;
      }
    }
  );
});