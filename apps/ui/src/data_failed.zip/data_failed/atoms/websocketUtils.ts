/**
 * WebSocket Integration Utilities
 *
 * Provides utilities for updating Jotai atoms based on WebSocket events
 * using configured cache strategies.
 */

import { WritableAtom } from "jotai";
import { queryClientAtom } from "jotai-tanstack-query";
import type { CacheStrategy } from "./cacheStrategyAtoms";

// Helper function to convert entity key to query key
const getQueryKeyFromEntityKey = (entityKey: string): string[] => {
  const parts = entityKey.split(":");
  return parts; // e.g., "initiative:org123:init456" → ["initiative", "org123", "init456"]
};

export const createWebSocketAtomUpdater = <T>(
  atom: WritableAtom<T | null, [T], void>,
  entityKey: string,
  strategy: CacheStrategy
) => {
  return {
    update: (newData: T, getAtomValue: any, setAtomValue: any, queryClient: any) => {
      switch (strategy) {
        case "INVALIDATE":
          // Traditional invalidation approach
          setAtomValue(atom, newData);
          queryClient.invalidateQueries(getQueryKeyFromEntityKey(entityKey));
          break;

        case "REFRESH_AFTER_SET":
          // Set data immediately for instant UI update
          setAtomValue(atom, newData);
          queryClient.setQueryData(getQueryKeyFromEntityKey(entityKey), newData);

          // Mark for background refetch to ensure server consistency
          queryClient.invalidateQueries(getQueryKeyFromEntityKey(entityKey), {
            refetchType: "inactive", // Only refetch if query is not currently active
          });
          break;

        case "MERGE":
          const current = getAtomValue(atom);
          const merged = { ...current, ...newData };
          setAtomValue(atom, merged);
          queryClient.setQueryData(getQueryKeyFromEntityKey(entityKey), merged);
          break;
      }
    },
  };
};