/**
 * Cache Strategy Atoms (WebSocket Events Only)
 *
 * Defines cache strategies for how WebSocket events should update
 * the TanStack Query cache through Jotai atoms.
 */

import { atom } from "jotai";
import { atomWithStorage } from "jotai/utils";

export type CacheStrategy = "INVALIDATE" | "MERGE" | "REFRESH_AFTER_SET";

// Global default strategy
export const defaultCacheStrategyAtom = atom<CacheStrategy>("REFRESH_AFTER_SET");

// Per-entity strategy overrides
export const entityCacheStrategyAtom = atomWithStorage<Record<string, CacheStrategy>>(
  "entity-cache-strategies",
  {}
);

// Strategy resolver utility
export const getCacheStrategyAtom = (entityType: string, entityId: string) =>
  atom((get) => {
    const entityStrategies = get(entityCacheStrategyAtom);
    const key = `${entityType}:${entityId}`;
    return entityStrategies[key] || get(defaultCacheStrategyAtom);
  });