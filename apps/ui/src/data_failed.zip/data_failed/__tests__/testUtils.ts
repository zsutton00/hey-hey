/**
 * Shared Testing Utilities for Jotai Data Layer Tests
 * 
 * This file provides common test utilities, custom render functions,
 * and MSW request handlers for testing the Jotai migration.
 */

import * as React from 'react';
import { render as rtlRender, type RenderOptions } from '@testing-library/react';
import { renderHook as rtlRenderHook, type RenderHookOptions } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Provider as JotaiProvider, createStore } from 'jotai';
import { http, HttpResponse } from 'msw';
import type { InitiativeResponseDto, CreateInitiativeDto, WorkStatus, Priority, InitiativeCreatorType } from '../../api';
import type { VersionConflictError } from '../../types/conversation';

// Create a fresh Jotai store for each test
export const createTestStore = () => createStore();

// Create a fresh QueryClient for each test
export const createTestQueryClient = () =>
  new QueryClient({
    defaultOptions: {
      queries: {
        retry: false, // Disable retries in tests
        gcTime: 0, // Disable garbage collection
      },
      mutations: {
        retry: false,
      },
    },
  });

// Custom render function with Jotai and QueryClient providers
interface CustomRenderOptions extends Omit<RenderOptions, 'wrapper'> {
  queryClient?: QueryClient;
  store?: ReturnType<typeof createTestStore>;
}

export function renderWithProviders(
  ui: React.ReactElement,
  options: CustomRenderOptions = {}
) {
  const { queryClient = createTestQueryClient(), store = createTestStore(), ...renderOptions } = options;

  function Wrapper({ children }: { children: React.ReactNode }) {
    return React.createElement(
      QueryClientProvider,
      { client: queryClient },
      React.createElement(JotaiProvider, { store }, children)
    );
  }

  return {
    ...rtlRender(ui, { wrapper: Wrapper, ...renderOptions }),
    queryClient,
    store,
  };
}

// Custom renderHook function with providers
interface CustomRenderHookOptions<TProps> extends Omit<RenderHookOptions<TProps>, 'wrapper'> {
  queryClient?: QueryClient;
  store?: ReturnType<typeof createTestStore>;
}

export function renderHookWithProviders<TResult, TProps>(
  renderCallback: (props: TProps) => TResult,
  options: CustomRenderHookOptions<TProps> = {}
) {
  const { queryClient = createTestQueryClient(), store = createTestStore(), ...renderOptions } = options;

  function Wrapper({ children }: { children: React.ReactNode }) {
    return React.createElement(
      QueryClientProvider,
      { client: queryClient },
      React.createElement(JotaiProvider, { store }, children)
    );
  }

  return {
    ...rtlRenderHook(renderCallback, { wrapper: Wrapper, ...renderOptions }),
    queryClient,
    store,
  };
}

// MSW Request Handlers for Platform API endpoints
export const createMSWHandlers = () => [
  // Get single initiative
  http.get('/api/organizations/:organizationId/initiatives/:initiativeId', ({ params }) => {
    const { organizationId, initiativeId } = params;
    const mockInitiative = createMockInitiativeResponseDto({
      id: initiativeId as string,
      organizationId: organizationId as string,
    });
    return HttpResponse.json({ data: mockInitiative });
  }),

  // Get initiatives list
  http.get('/api/organizations/:organizationId/initiatives', ({ params }) => {
    const { organizationId } = params;
    const mockInitiatives = [
      createMockInitiativeResponseDto({
        id: 'init-1',
        organizationId: organizationId as string,
        name: 'First Initiative',
      }),
      createMockInitiativeResponseDto({
        id: 'init-2',
        organizationId: organizationId as string,
        name: 'Second Initiative',
      }),
    ];
    return HttpResponse.json({ data: mockInitiatives });
  }),

  // Create initiative
  http.post('/api/organizations/:organizationId/initiatives', async ({ request, params }) => {
    const { organizationId } = params;
    const createData = await request.json() as CreateInitiativeDto;
    const newInitiative = createMockInitiativeResponseDto({
      id: `init-${Date.now()}`,
      organizationId: organizationId as string,
      name: createData.name,
      description: createData.description,
      details: createData.details,
      acceptanceCriteria: createData.acceptanceCriteria,
      assigneeId: createData.assigneeId,
      reasoning: createData.reasoning,
      status: createData.status,
      priority: createData.priority,
      creatorType: createData.creatorType,
      dueDate: createData.dueDate,
      tags: createData.tags,
      sourceConversationId: createData.sourceConversationId,
    });
    return HttpResponse.json({ data: newInitiative }, { status: 201 });
  }),

  // Update initiative
  http.put('/api/initiatives/:initiativeId', async ({ request, params }) => {
    const { initiativeId } = params;
    const updateData = await request.json() as Partial<CreateInitiativeDto>;
    const updatedInitiative = createMockInitiativeResponseDto({
      id: initiativeId as string,
      ...updateData,
      updatedAt: new Date().toISOString(),
    });
    return HttpResponse.json({ data: updatedInitiative });
  }),

  // Delete initiative
  http.delete('/api/initiatives/:initiativeId', () => {
    return HttpResponse.json({ success: true });
  }),
];

// MSW Error Handlers for testing failure scenarios
export const createErrorHandlers = () => [
  // Version conflict error
  http.put('/api/initiatives/:initiativeId/conflict', () => {
    const versionConflictError: VersionConflictError = {
      error: 'VERSION_CONFLICT',
      message: 'The initiative has been updated by another user.',
      currentVersion: 5,
      expectedVersion: 3,
      latestConversation: {
        id: 'conv-123',
        version: 5,
        messages: [],
        projectId: 'proj-456',
      } as never, // Type assertion to avoid deep type dependencies
    };
    return HttpResponse.json(versionConflictError, { status: 409 });
  }),

  // Network error
  http.get('/api/organizations/:organizationId/initiatives/network-error', () => {
    return HttpResponse.error();
  }),

  // Server error
  http.get('/api/organizations/:organizationId/initiatives/server-error', () => {
    return HttpResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }),
];

// Common test setup and teardown utilities
export const setupTestEnvironment = () => {
  const queryClient = createTestQueryClient();
  const store = createTestStore();
  
  return {
    queryClient,
    store,
    cleanup: () => {
      queryClient.clear();
      store.get = createTestStore().get; // Reset store
    },
  };
};

// Helper for testing loading states
export const waitForQueryToLoad = async (queryClient: QueryClient, queryKey: string[]) => {
  return new Promise<void>((resolve) => {
    const unsubscribe = queryClient.getQueryCache().subscribe((event) => {
      if (
        event.type === 'updated' &&
        event.query.queryKey.toString() === queryKey.toString() &&
        event.query.state.status !== 'pending'
      ) {
        unsubscribe();
        resolve();
      }
    });
  });
};

// Helper for testing mutation states
export const waitForMutationToComplete = async (queryClient: QueryClient) => {
  return new Promise<void>((resolve) => {
    const unsubscribe = queryClient.getMutationCache().subscribe((event) => {
      if (
        event.type === 'updated' &&
        (event.mutation.state.status === 'success' || event.mutation.state.status === 'error')
      ) {
        unsubscribe();
        resolve();
      }
    });
  });
};

// Mock data factory (basic implementation - will be expanded in mockData.ts)
export const createMockInitiativeResponseDto = (
  overrides: Partial<InitiativeResponseDto> = {}
): InitiativeResponseDto => ({
  id: 'init-123',
  name: 'Test Initiative',
  description: 'A test initiative for unit testing',
  details: 'Technical implementation details',
  acceptanceCriteria: 'Success criteria for completion',
  assigneeId: 'user-456',
  reasoning: 'This initiative was created for testing purposes',
  status: 'ACTIVE' as WorkStatus,
  priority: 'MEDIUM' as Priority,
  creatorType: 'USER' as InitiativeCreatorType,
  dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), // 7 days from now
  tags: ['test', 'automation'],
  organizationId: 'org-789',
  sourceConversationId: 'conv-101',
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
  ...overrides,
});

// Test assertion helpers
export const expectInitiativeToMatch = (
  actual: InitiativeResponseDto,
  expected: Partial<InitiativeResponseDto>
) => {
  Object.entries(expected).forEach(([key, value]) => {
    if (value !== undefined) {
      expect(actual[key as keyof InitiativeResponseDto]).toEqual(value);
    }
  });
};

// Cache validation helpers
export const getCachedInitiative = (
  queryClient: QueryClient,
  organizationId: string,
  initiativeId: string
): InitiativeResponseDto | undefined => {
  return queryClient.getQueryData(['initiatives', 'detail', organizationId, initiativeId]);
};

export const getCachedInitiativesList = (
  queryClient: QueryClient,
  organizationId: string
): InitiativeResponseDto[] | undefined => {
  return queryClient.getQueryData(['initiatives', 'list', organizationId]);
};

// WebSocket Mock Helpers
export const createMockWebSocketServer = (url: string) => {
  // Using jest-websocket-mock (WS) which was imported in setup.ts
  const WS = globalThis.WS || require('jest-websocket-mock');
  return new WS(url);
};

export const simulateWebSocketEvent = (
  server: unknown,
  event: { type: string; data: unknown }
) => {
  // Send message to all connected clients
  if (server && typeof server === 'object' && 'send' in server) {
    (server as { send: (data: string) => void }).send(JSON.stringify(event));
  }
};

export const createMockWebSocketEventHandlers = () => {
  const events: Array<{ type: string; data: unknown; timestamp: number }> = [];
  
  return {
    events,
    addEvent: (type: string, data: unknown) => {
      events.push({ type, data, timestamp: Date.now() });
    },
    clearEvents: () => {
      events.length = 0;
    },
    getEventsByType: (type: string) => {
      return events.filter(event => event.type === type);
    },
    getLatestEvent: () => {
      return events[events.length - 1];
    },
  };
};