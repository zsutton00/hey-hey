/**
 * Mock Data Factories for Testing
 * 
 * This file provides mock data factories for creating realistic test data
 * for Jotai migration tests. All factories support partial overrides.
 */

import type { 
  InitiativeResponseDto, 
  CreateInitiativeDto, 
  WorkStatus, 
  Priority, 
  InitiativeCreatorType,
  ConversationResponseDto,
  ProjectResponseDto
} from '../../api';
import type { 
  VersionConflictError, 
  VersionedConversationResponseDto, 
  VersionedCreateUserMessage,
  VersionedWebSocketMessage,
  OptimisticMessageState 
} from '../../types/conversation';

// Counters for generating unique IDs
let initiativeCounter = 1;
let conversationCounter = 1;
let messageCounter = 1;
let projectCounter = 1;
let userCounter = 1;
let organizationCounter = 1;

// Reset counters for test isolation
export const resetMockCounters = () => {
  initiativeCounter = 1;
  conversationCounter = 1;
  messageCounter = 1;
  projectCounter = 1;
  userCounter = 1;
  organizationCounter = 1;
};

// Initiative Mock Factories
export const createMockInitiativeResponseDto = (
  overrides: Partial<InitiativeResponseDto> = {}
): InitiativeResponseDto => ({
  id: `init-${initiativeCounter++}`,
  name: `Test Initiative ${initiativeCounter}`,
  description: 'A comprehensive test initiative for validating system functionality',
  details: 'Technical implementation details including architecture decisions and implementation approach',
  acceptanceCriteria: 'Success criteria that define when this initiative is considered complete',
  assigneeId: `user-${userCounter}`,
  reasoning: 'This initiative addresses critical system requirements and aligns with organizational goals',
  status: 'BACKLOG' as WorkStatus,
  priority: 'MEDIUM' as Priority,
  creatorType: 'USER' as InitiativeCreatorType,
  dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString(), // 2 weeks from now
  tags: ['test', 'automation', 'quality-assurance'],
  organizationId: `org-${organizationCounter}`,
  sourceConversationId: `conv-${conversationCounter}`,
  createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(), // 1 day ago
  updatedAt: new Date().toISOString(),
  ...overrides,
});

export const createMockCreateInitiativeDto = (
  overrides: Partial<CreateInitiativeDto> = {}
): CreateInitiativeDto => ({
  name: `New Initiative ${initiativeCounter++}`,
  description: 'A new initiative created for testing purposes',
  details: 'Technical details and implementation considerations',
  acceptanceCriteria: 'Success criteria for completion',
  assigneeId: `user-${userCounter}`,
  reasoning: 'This initiative was identified as high priority for organizational success',
  status: 'BACKLOG' as WorkStatus,
  priority: 'MEDIUM' as Priority,
  creatorType: 'USER' as InitiativeCreatorType,
  dueDate: new Date(Date.now() + 21 * 24 * 60 * 60 * 1000).toISOString(), // 3 weeks from now
  tags: ['new', 'testing'],
  sourceConversationId: `conv-${conversationCounter}`,
  ...overrides,
});

// Initiative Lists with different statuses
export const createMockInitiativesList = (count = 5): InitiativeResponseDto[] => {
  const statuses: WorkStatus[] = ['BACKLOG', 'ACTIVE', 'ON_HOLD', 'COMPLETED', 'CANCELLED'];
  const priorities: Priority[] = ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'];
  
  return Array.from({ length: count }, (_, index) => {
    const statusIndex = index % statuses.length;
    const priorityIndex = index % priorities.length;
    
    return createMockInitiativeResponseDto({
      name: `Initiative ${index + 1}`,
      description: `Description for initiative ${index + 1}`,
      status: statuses[statusIndex],
      priority: priorities[priorityIndex],
      tags: [`tag-${index}`, `category-${statusIndex}`],
    });
  });
};

// Conversation Mock Factories
export const createMockConversationResponseDto = (
  overrides: Partial<ConversationResponseDto> = {}
): ConversationResponseDto => ({
  id: `conv-${conversationCounter++}`,
  projectId: `proj-${projectCounter}`,
  status: 'ACTIVE',
  messages: [],
  createdAt: new Date(Date.now() - 60 * 60 * 1000).toISOString(), // 1 hour ago
  updatedAt: new Date().toISOString(),
  ...overrides,
} as ConversationResponseDto);

export const createMockVersionedConversationResponseDto = (
  overrides: Partial<VersionedConversationResponseDto> = {}
): VersionedConversationResponseDto => ({
  ...createMockConversationResponseDto(),
  version: 1,
  ...overrides,
});

// Message Mock Factories (simplified for testing)
export const createMockMessageId = (): string => `msg-${messageCounter++}`;

// Project Mock Factories
export const createMockProjectResponseDto = (
  overrides: Partial<ProjectResponseDto> = {}
): ProjectResponseDto => ({
  id: `proj-${projectCounter++}`,
  name: `Test Project ${projectCounter}`,
  description: 'A test project for validating functionality',
  organizationId: `org-${organizationCounter}`,
  createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(), // 1 week ago
  updatedAt: new Date().toISOString(),
  ...overrides,
} as ProjectResponseDto);

// WebSocket Event Mock Factories
export const createMockWebSocketMessage = (
  overrides: Partial<VersionedWebSocketMessage> = {}
): VersionedWebSocketMessage => ({
  type: 'conversation_update',
  conversationId: `conv-${conversationCounter}`,
  version: 1,
  timestamp: Date.now(),
  eventType: 'initiative_updated',
  ...overrides,
});

// WebSocket event types for initiatives
export const createMockInitiativeWebSocketEvent = (
  type: 'initiative_created' | 'initiative_updated' | 'initiative_deleted',
  initiative: InitiativeResponseDto,
  overrides: Partial<VersionedWebSocketMessage> = {}
): VersionedWebSocketMessage => ({
  type: 'conversation_update',
  conversationId: initiative.sourceConversationId || `conv-${conversationCounter}`,
  version: Date.now(), // Use timestamp as version for uniqueness
  timestamp: Date.now(),
  eventType: type,
  ...overrides,
});

// Error Mock Factories
export const createMockVersionConflictError = (
  overrides: Partial<VersionConflictError> = {}
): VersionConflictError => ({
  error: 'VERSION_CONFLICT',
  message: 'The conversation has been updated by another user. Please refresh and try again.',
  currentVersion: 5,
  expectedVersion: 3,
  latestConversation: createMockVersionedConversationResponseDto({
    version: 5,
    updatedAt: new Date().toISOString(),
  }),
  ...overrides,
});

// Optimistic Update Mock Factories
export const createMockOptimisticMessageState = (
  overrides: Partial<OptimisticMessageState> = {}
): OptimisticMessageState => ({
  parentMessageId: `msg-${messageCounter}`,
  formData: {
    message: 'This is an optimistic update test message',
    priority: 'MEDIUM',
  },
  status: 'sending',
  timestamp: Date.now(),
  expectedVersion: 3,
  ...overrides,
});

export const createMockVersionedCreateUserMessage = (
  overrides: Partial<VersionedCreateUserMessage> = {}
): VersionedCreateUserMessage => ({
  content: 'Test user message with version control',
  conversationId: `conv-${conversationCounter}`,
  expectedConversationVersion: 1,
  ...overrides,
} as VersionedCreateUserMessage);

// Batch Data Creation Utilities
export const createMockOrganizationData = (organizationId: string) => {
  organizationCounter = parseInt(organizationId.replace('org-', '')) || organizationCounter;
  
  const projects = Array.from({ length: 3 }, () => 
    createMockProjectResponseDto({ organizationId })
  );
  
  const initiatives = Array.from({ length: 8 }, () => 
    createMockInitiativeResponseDto({ organizationId })
  );
  
  const conversations = Array.from({ length: 5 }, (_, index) => 
    createMockVersionedConversationResponseDto({ 
      projectId: projects[index % projects.length].id 
    })
  );
  
  return {
    organizationId,
    projects,
    initiatives,
    conversations,
  };
};

// Cache State Mock Factories
export const createMockCacheState = () => ({
  queries: new Map(),
  mutations: new Map(),
  subscriptions: new Map(),
});

// Test Scenario Data Sets
export const createMockTestScenarios = () => ({
  // Happy path: successful operations
  successfulCreate: {
    request: createMockCreateInitiativeDto({
      name: 'Successful Create Test',
      description: 'Testing successful initiative creation',
    }),
    response: createMockInitiativeResponseDto({
      name: 'Successful Create Test',
      description: 'Testing successful initiative creation',
      status: 'BACKLOG' as WorkStatus,
    }),
  },
  
  // Conflict scenario: version mismatch
  versionConflict: {
    error: createMockVersionConflictError({
      message: 'Initiative updated by another user',
      currentVersion: 7,
      expectedVersion: 5,
    }),
  },
  
  // Network error scenario
  networkError: {
    error: new Error('Network request failed'),
  },
  
  // Large dataset scenario
  largeDataset: {
    initiatives: createMockInitiativesList(50),
    conversations: Array.from({ length: 20 }, () => 
      createMockVersionedConversationResponseDto()
    ),
  },
  
  // WebSocket events sequence
  websocketSequence: [
    createMockInitiativeWebSocketEvent('initiative_created', 
      createMockInitiativeResponseDto({ name: 'WebSocket Test 1' })
    ),
    createMockInitiativeWebSocketEvent('initiative_updated', 
      createMockInitiativeResponseDto({ name: 'WebSocket Test 1 - Updated' })
    ),
    createMockInitiativeWebSocketEvent('initiative_deleted', 
      createMockInitiativeResponseDto({ name: 'WebSocket Test 1 - Updated' })
    ),
  ],
});

// Utility Functions
export const getRandomItem = <T>(array: T[]): T => {
  return array[Math.floor(Math.random() * array.length)];
};

export const createMockPaginatedResponse = <T>(
  items: T[],
  page = 1,
  limit = 10
) => {
  const startIndex = (page - 1) * limit;
  const endIndex = startIndex + limit;
  const paginatedItems = items.slice(startIndex, endIndex);
  
  return {
    data: paginatedItems,
    pagination: {
      page,
      limit,
      total: items.length,
      totalPages: Math.ceil(items.length / limit),
      hasNext: endIndex < items.length,
      hasPrev: page > 1,
    },
  };
};