/**
 * Updated Hook Implementation using Jotai Atoms
 *
 * This file provides the new atom-backed versions of initiative hooks
 * that replace the existing TanStack Query implementations.
 */

import { useMemo } from "react";
import { useAtomValue, useSetAtom } from "jotai";
import type { InitiativeResponseDto } from "../../api";
import type { UseInitiativeOptions, UseInitiativesOptions } from "../core/initiatives";
import { 
  initiativeAtomFamily, 
  organizationInitiativesAtomFamily 
} from "../atoms/initiativeAtoms";

// ============================================================================
// UPDATED HOOK IMPLEMENTATIONS
// ============================================================================

/**
 * Enhanced useInitiative hook using Jotai atoms
 * 
 * Replaces the existing TanStack Query implementation with atom-based approach
 * that includes WebSocket update capability.
 */
export const useInitiative = (
  orgId: string,
  initiativeId: string,
  options: UseInitiativeOptions = {}
) => {
  // Use atomFamily for automatic registry/caching
  const initiativeAtom = useMemo(
    () => initiativeAtomFamily({ orgId, initiativeId }),
    [orgId, initiativeId]
  );

  // Read from atom (which internally uses atomWithQuery)
  const atomResult = useAtomValue(initiativeAtom);

  // Return TanStack Query compatible interface
  return {
    data: atomResult.data,
    isLoading: atomResult.isLoading,
    error: atomResult.error,
    refetch: atomResult.refetch,
    // Atom provides WebSocket update capability (for WebSocket manager only)
    atomicUpdate: useSetAtom(initiativeAtom),
  };
};

/**
 * Enhanced useInitiatives hook using Jotai atoms
 * 
 * Replaces the existing TanStack Query implementation with atom-based approach
 * that includes WebSocket list update capability.
 */
export const useInitiatives = (
  orgId: string,
  options: UseInitiativesOptions = {}
) => {
  const initiativesAtom = useMemo(
    () => organizationInitiativesAtomFamily(orgId),
    [orgId]
  );

  const atomResult = useAtomValue(initiativesAtom);
  const updateList = useSetAtom(initiativesAtom);

  return {
    data: atomResult.data,
    isLoading: atomResult.isLoading,
    error: atomResult.error,
    refetch: atomResult.refetch,
    // List-specific atomic operations (for WebSocket manager only)
    updateInitiative: (data: InitiativeResponseDto, queryClient: any) =>
      updateList({ action: "update", data, queryClient }),
    createInitiative: (data: InitiativeResponseDto, queryClient: any) =>
      updateList({ action: "create", data, queryClient }),
    deleteInitiative: (data: InitiativeResponseDto, queryClient: any) =>
      updateList({ action: "delete", data, queryClient }),
  };
};