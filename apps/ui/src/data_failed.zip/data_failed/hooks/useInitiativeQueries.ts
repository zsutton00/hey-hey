/**
 * Enhanced Initiative Query Hooks with Auto-WebSocket Integration
 *
 * This file provides enhanced versions of the core initiative query hooks
 * that automatically set up WebSocket subscriptions for real-time updates.
 *
 * Features:
 * - Automatic WebSocket subscription management
 * - Smart deduplication via subscription manager
 * - Conflict resolution for race conditions
 * - Comprehensive event logging
 * - Backwards compatibility with existing code
 */

import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useCallback, useEffect } from "react";
import type {
  InitiativeResponseDto,
  InitiativeStatusChangedEvent,
  InitiativeUpdatedEvent,
} from "../../api";
import { platformClient } from "../../clients/serviceClients";
import {
  type UseInitiativeOptions,
  type UseInitiativesOptions,
  initiativeKeys,
} from "../core/initiatives";
import {
  handleInitiativeWebSocketUpdateWithConflictResolution,
  subscriptionManager,
} from "../initiatives";

// ============================================================================
// ENHANCED TYPES
// ============================================================================

export interface EnhancedUseInitiativeOptions extends UseInitiativeOptions {
  /**
   * Automatically set up WebSocket subscription for real-time updates.
   * @default true
   */
  enableAutoWebSocket?: boolean;

  /**
   * Fields to preserve during optimistic updates when WebSocket events occur.
   * Useful for preventing overwrite of user inputs during typing.
   */
  preserveOptimisticFields?: string[];
}

export interface EnhancedUseInitiativesOptions extends UseInitiativesOptions {
  /**
   * Automatically set up WebSocket subscription for real-time updates.
   * @default true
   */
  enableAutoWebSocket?: boolean;
}

// ============================================================================
// ENHANCED INITIATIVE HOOK
// ============================================================================

/**
 * Enhanced useInitiative hook with automatic WebSocket integration.
 *
 * Automatically sets up WebSocket subscriptions to keep initiative data
 * up-to-date with real-time changes from other users or system updates.
 *
 * @param orgId Organization ID
 * @param initiativeId Initiative ID
 * @param options Query options including WebSocket configuration
 */
export const useInitiative = (
  orgId: string,
  initiativeId: string,
  options: EnhancedUseInitiativeOptions = {}
) => {
  const {
    enableAutoWebSocket = true,
    preserveOptimisticFields = [],
    ...queryOptions
  } = options;

  // Get QueryClient using the hook - this ensures it's always available
  const queryClient = useQueryClient();

  // Core query - unchanged from original implementation
  const queryKey = initiativeKeys.detail(orgId, initiativeId);
  const query = useQuery({
    queryKey,
    queryFn: async () => {
      const response = await platformClient.getInitiative(orgId, initiativeId);
      const httpData = response.data.data as InitiativeResponseDto;

      // Check if there's fresher data in cache already (from WebSocket updates)
      const currentData =
        queryClient.getQueryData<InitiativeResponseDto>(queryKey);
      if (currentData && currentData.updatedAt && httpData.updatedAt) {
        const currentTime = new Date(currentData.updatedAt);
        const httpTime = new Date(httpData.updatedAt);

        if (currentTime > httpTime) {
          console.log(
            `🛢 [HTTP] Ignoring stale HTTP response for ${initiativeId}`,
            {
              current: currentTime.toISOString(),
              http: httpTime.toISOString(),
            }
          );
          return currentData; // Return the fresher cached data instead
        }
      }

      return httpData;
    },
    enabled: !!(orgId && initiativeId),
    staleTime: 2 * 60 * 1000, // 2 minutes
    gcTime: 30 * 60 * 1000, // 30 minutes
    ...queryOptions,
  });

  // Event handlers for WebSocket integration
  const handleInitiativeUpdated = useCallback(
    (event: InitiativeUpdatedEvent) => {
      console.log(
        `🛢 [AUTO-WS] Initiative updated event for ${initiativeId}`,
        event
      );

      // Only process updates for this specific initiative
      if (event.initiativeId !== initiativeId) {
        return;
      }

      subscriptionManager.logEvent({
        type: "websocket_event",
        data: {
          eventType: "initiative.updated",
          initiativeId: event.initiativeId,
          hasInitiativeData: !!event.initiative,
          timestamp: event.timestamp,
        },
        source: "useInitiative",
      });

      // Apply cache update with conflict resolution
      if (event.initiative) {
        handleInitiativeWebSocketUpdateWithConflictResolution(
          queryClient,
          orgId,
          initiativeId,
          event.initiative,
          {
            eventTimestamp: event.timestamp,
            preserveOptimisticFields,
            source: "initiative_updated_websocket",
          }
        );
      } else {
        queryClient.invalidateQueries({
          queryKey: initiativeKeys.detail(orgId, initiativeId),
        });
      }
    },
    [queryClient, orgId, initiativeId, preserveOptimisticFields]
  );

  const handleInitiativeStatusChanged = useCallback(
    (event: InitiativeStatusChangedEvent) => {
      console.log(
        `🛢 [AUTO-WS] Initiative status changed for ${initiativeId}`,
        event
      );

      if (event.initiativeId !== initiativeId) {
        return;
      }

      subscriptionManager.logEvent({
        type: "websocket_event",
        data: {
          eventType: "initiative.status_changed",
          initiativeId: event.initiativeId,
          newStatus: event.initiative?.status,
          timestamp: event.timestamp,
        },
        source: "useInitiative",
      });

      // Status changes require full data refresh
      queryClient.invalidateQueries({
        queryKey: initiativeKeys.detail(orgId, initiativeId),
      });
    },
    [queryClient, orgId, initiativeId]
  );

  const handleConversationUpdated = useCallback(() => {
    console.log(
      `🛢 [AUTO-WS] Conversation updated - refreshing initiative ${initiativeId}`
    );

    // Conversation updates might affect initiative data
    queryClient.invalidateQueries({
      queryKey: initiativeKeys.detail(orgId, initiativeId),
    });
  }, [queryClient, orgId, initiativeId]);

  // Auto-WebSocket subscription setup
  useEffect(() => {
    if (!enableAutoWebSocket || !orgId || !initiativeId) {
      return;
    }

    const subscriptionKey = `initiative:${orgId}:${initiativeId}`;

    console.log(
      `🛢 [AUTO-WS] Setting up auto-WebSocket for initiative ${initiativeId}`
    );

    // Subscribe with smart deduplication
    const unsubscribe = subscriptionManager.subscribe(subscriptionKey, {
      projectIds: [], // Will be populated when we have the data
      initiativeIds: [initiativeId],
      events: {
        onInitiativeUpdated: handleInitiativeUpdated,
        onInitiativeStatusChanged: handleInitiativeStatusChanged,
        onConversationUpdated: handleConversationUpdated,
      },
    });

    console.log(
      `🛢 [AUTO-WS] Subscribed to real-time updates for initiative ${initiativeId}`
    );

    return () => {
      console.log(
        `🛢 [AUTO-WS] Cleaning up auto-WebSocket for initiative ${initiativeId}`
      );
      unsubscribe();
    };
  }, [
    enableAutoWebSocket,
    orgId,
    initiativeId,
    handleInitiativeUpdated,
    handleInitiativeStatusChanged,
    handleConversationUpdated,
  ]);

  return query;
};

// ============================================================================
// ENHANCED INITIATIVES LIST HOOK
// ============================================================================

/**
 * Enhanced useInitiatives hook with automatic WebSocket integration.
 *
 * Automatically sets up WebSocket subscriptions to keep initiatives list
 * up-to-date with real-time changes.
 */
export const useInitiatives = (
  orgId: string,
  options: EnhancedUseInitiativesOptions = {}
) => {
  const { enableAutoWebSocket = true, ...queryOptions } = options;

  // Get QueryClient using the hook - this ensures it's always available
  const queryClient = useQueryClient();

  // Core query with conflict resolution for HTTP responses
  const queryKey = initiativeKeys.list(orgId);
  const query = useQuery({
    queryKey,
    queryFn: async () => {
      const response = await platformClient.getOrganizationInitiatives(orgId);
      const httpData = response.data.data as InitiativeResponseDto[];

      // For lists, we don't have a simple timestamp comparison
      // since it's an array. We'll return the HTTP data as-is for now.
      // Individual initiative updates are handled by the detail hook's conflict resolution.
      return httpData;
    },
    enabled: !!orgId,
    staleTime: 60 * 1000, // 1 minute
    gcTime: 10 * 60 * 1000, // 10 minutes
    ...queryOptions,
  });

  // Event handlers for list updates
  const handleInitiativeUpdated = useCallback(
    (event: InitiativeUpdatedEvent) => {
      console.log(`🔄 [AUTO-WS] Initiative updated in list view`, event);

      subscriptionManager.logEvent({
        type: "websocket_event",
        data: {
          eventType: "initiative.updated",
          initiativeId: event.initiativeId,
          listView: true,
          timestamp: event.timestamp,
        },
        source: "useInitiatives",
      });

      // For list views, we typically just invalidate to refetch
      // Since we don't know which specific initiatives are in the current list
      queryClient.invalidateQueries({
        queryKey: initiativeKeys.list(orgId),
      });
    },
    [queryClient, orgId]
  );

  const handleInitiativeCreated = useCallback(
    (event: { aggregateId: string }) => {
      console.log(`🎉 [AUTO-WS] New initiative created in org`, event);

      subscriptionManager.logEvent({
        type: "websocket_event",
        data: {
          eventType: "initiative.created",
          aggregateId: event.aggregateId,
          listView: true,
        },
        source: "useInitiatives",
      });

      // New initiatives should refresh the list
      queryClient.invalidateQueries({
        queryKey: initiativeKeys.list(orgId),
      });
    },
    [queryClient, orgId]
  );

  // Auto-WebSocket subscription for organization-level events
  useEffect(() => {
    if (!enableAutoWebSocket || !orgId) {
      return;
    }

    const subscriptionKey = `initiatives-list:${orgId}`;

    console.log(
      `🛢 [AUTO-WS] Setting up auto-WebSocket for initiatives list in org ${orgId}`
    );

    const unsubscribe = subscriptionManager.subscribe(subscriptionKey, {
      // Subscribe to all initiatives in this organization
      organizationIds: [orgId],
      events: {
        onInitiativeCreated: handleInitiativeCreated,
        onInitiativeUpdated: handleInitiativeUpdated,
        // Status changes and deletions will also trigger initiative updates
        onInitiativeStatusChanged: handleInitiativeUpdated,
      },
    });

    console.log(
      `🛢 [AUTO-WS] Subscribed to real-time updates for initiatives list in org ${orgId}`
    );

    return () => {
      console.log(
        `🛢 [AUTO-WS] Cleaning up auto-WebSocket for initiatives list in org ${orgId}`
      );
      unsubscribe();
    };
  }, [
    enableAutoWebSocket,
    orgId,
    handleInitiativeCreated,
    handleInitiativeUpdated,
  ]);

  return query;
};

// ============================================================================
// INITIATIVE CONVERSATION HOOK (Enhanced)
// ============================================================================

/**
 * Enhanced hook for fetching initiative conversation data with WebSocket integration.
 */
export const useInitiativeConversation = (
  orgId: string,
  initiativeId: string,
  conversationId: string,
  options: EnhancedUseInitiativeOptions = {}
) => {
  const { enableAutoWebSocket = true, ...queryOptions } = options;

  // Core query for conversation data
  const query = useQuery({
    queryKey: [
      ...initiativeKeys.detail(orgId, initiativeId),
      "conversation",
      conversationId,
    ],
    queryFn: async () => {
      const response = await platformClient.getConversation(conversationId);
      return response.data.data;
    },
    enabled: !!(orgId && initiativeId && conversationId),
    staleTime: 30 * 1000, // 30 seconds for conversations (more dynamic)
    gcTime: 5 * 60 * 1000, // 5 minutes
    ...queryOptions,
  });

  const queryClient = useQueryClient();

  // Handle conversation updates that might affect the initiative
  const handleConversationUpdated = useCallback(
    (_event: { aggregateId: string }) => {
      console.log(
        `🔄 [AUTO-WS] Conversation updated for initiative ${initiativeId}`
      );

      // Conversation updates might contain new initiative insights
      queryClient.invalidateQueries({
        queryKey: initiativeKeys.detail(orgId, initiativeId),
      });

      // Also refresh the conversation data itself
      queryClient.invalidateQueries({
        queryKey: [
          ...initiativeKeys.detail(orgId, initiativeId),
          "conversation",
          conversationId,
        ],
      });
    },
    [queryClient, orgId, initiativeId, conversationId]
  );

  // Auto-WebSocket subscription
  useEffect(() => {
    if (!enableAutoWebSocket || !orgId || !initiativeId || !conversationId) {
      return;
    }

    const subscriptionKey = `initiative-conversation:${orgId}:${initiativeId}:${conversationId}`;

    const unsubscribe = subscriptionManager.subscribe(subscriptionKey, {
      conversationIds: [conversationId],
      initiativeIds: [initiativeId],
      events: {
        onConversationUpdated: handleConversationUpdated,
      },
    });

    return () => {
      unsubscribe();
    };
  }, [
    enableAutoWebSocket,
    orgId,
    initiativeId,
    conversationId,
    handleConversationUpdated,
  ]);

  return query;
};
