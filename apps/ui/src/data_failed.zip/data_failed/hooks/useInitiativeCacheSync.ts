/**
 * WebSocket Cache Synchronization for Initiatives
 *
 * Automatically synchronizes TanStack Query cache with WebSocket events
 * for real-time initiative updates without manual cache management.
 */

import { useCallback, useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useWebSocketService } from "../../hooks/useWebSocketService";
import { useAuth } from "../../contexts/AuthContext";
import {
  handleInitiativeWebSocketUpdate,
  handleInitiativeWebSocketCreation,
  invalidateInitiativeListsCache,
} from "../utils/cacheUtils";
import type {
  InitiativeUpdatedEvent,
  InitiativeStatusChangedEvent,
  InitiativeCreatedEvent,
} from "../../api";

interface UseInitiativeCacheSyncOptions {
  /**
   * Organization ID to sync cache for
   */
  organizationId: string;

  /**
   * Project ID to subscribe to WebSocket events for
   */
  projectId?: string;

  /**
   * Specific initiative ID to sync (optional - if not provided, syncs all initiatives)
   */
  initiativeId?: string;

  /**
   * Whether to enable WebSocket sync
   */
  enabled?: boolean;

  /**
   * Custom user ID (defaults to authenticated user)
   */
  userId?: string;
}

interface UseInitiativeCacheSyncReturn {
  isConnected: boolean;
  isAuthenticated: boolean;
  connectionError: string | null;
}

/**
 * Automatically sync TanStack Query cache with WebSocket initiative events.
 *
 * This hook:
 * - Subscribes to initiative WebSocket events
 * - Automatically invalidates relevant query cache entries
 * - Handles optimistic updates where possible
 * - Provides real-time cache synchronization
 *
 * @param options - Configuration options
 */
export const useInitiativeCacheSync = ({
  organizationId,
  projectId,
  initiativeId,
  enabled = true,
  userId,
}: UseInitiativeCacheSyncOptions): UseInitiativeCacheSyncReturn => {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const actualUserId = user?.id || userId || "anonymous";

  // Handle initiative update events
  const handleInitiativeUpdated = useCallback(
    (event: InitiativeUpdatedEvent) => {
      console.log("🛢 [CACHE SYNC] Initiative updated", {
        eventInitiativeId: event.initiativeId,
        targetInitiativeId: initiativeId,
        organizationId,
        hasInitiativeData: !!event.initiative,
      });

      // If we're listening for a specific initiative, only handle that one
      if (initiativeId && event.initiativeId !== initiativeId) {
        return;
      }

      // Update cache with new data
      handleInitiativeWebSocketUpdate(
        queryClient,
        organizationId,
        event.initiativeId,
        event.initiative
      );
    },
    [queryClient, organizationId, initiativeId]
  );

  // Handle initiative creation events
  const handleInitiativeCreated = useCallback(
    (event: InitiativeCreatedEvent) => {
      console.log("🛢 [CACHE SYNC] Initiative created", {
        organizationId,
        event,
      });

      // For creation events, we typically want to invalidate lists
      // since we might not have the full initiative data in the event
      handleInitiativeWebSocketCreation(queryClient);
    },
    [queryClient]
  );

  // Handle initiative status change events
  const handleInitiativeStatusChanged = useCallback(
    (event: InitiativeStatusChangedEvent) => {
      console.log("🛢 [CACHE SYNC] Initiative status changed", {
        eventInitiativeId: event.initiativeId,
        targetInitiativeId: initiativeId,
        organizationId,
      });

      // If we're listening for a specific initiative, only handle that one
      if (initiativeId && event.initiativeId !== initiativeId) {
        return;
      }

      // Status changes should invalidate the specific initiative and lists
      handleInitiativeWebSocketUpdate(
        queryClient,
        organizationId,
        event.initiativeId,
        event.initiative ? { status: event.initiative.status } : undefined
      );
    },
    [queryClient, organizationId, initiativeId]
  );

  // Note: Initiative deletion events are not yet implemented in the WebSocket service
  // const handleInitiativeDeleted = useCallback(
  //   (event: { initiativeId: string }) => {
  //     console.log("🛢 [CACHE SYNC] Initiative deleted", {
  //       eventInitiativeId: event.initiativeId,
  //       organizationId,
  //     });

  //     handleInitiativeWebSocketDeletion(
  //       queryClient,
  //       organizationId,
  //       event.initiativeId
  //     );
  //   },
  //   [queryClient, organizationId]
  // );

  // Handle conversation updates that might affect initiatives
  const handleConversationUpdated = useCallback(() => {
    console.log(
      "🛢 [CACHE SYNC] Conversation updated - invalidating initiative lists"
    );

    // Conversation updates might affect initiative data, so invalidate lists
    invalidateInitiativeListsCache(queryClient);

    // If we're tracking a specific initiative, also invalidate it
    if (initiativeId) {
      handleInitiativeWebSocketUpdate(
        queryClient,
        organizationId,
        initiativeId
      );
    }
  }, [queryClient, organizationId, initiativeId]);

  // Determine connection parameters
  const shouldConnect = enabled && !!organizationId;
  const projectIds = projectId ? [projectId] : [];
  const initiativeIds = initiativeId ? [initiativeId] : [];

  // Set up WebSocket connection with event handlers
  const websocketState = useWebSocketService({
    userId: actualUserId,
    projectIds,
    conversationIds: [], // We don't need specific conversation IDs
    initiativeIds,
    autoConnect: shouldConnect,
    events: shouldConnect
      ? {
          onInitiativeUpdated: handleInitiativeUpdated,
          onInitiativeCreated: handleInitiativeCreated,
          onInitiativeStatusChanged: handleInitiativeStatusChanged,
          // onInitiativeDeleted: handleInitiativeDeleted, // Add this when the event type is available
          onConversationUpdated: handleConversationUpdated,

          // Handle system notifications that might affect cache
          onSystemNotification: () => {
            console.log(
              "🛢 [CACHE SYNC] System notification - invalidating cache"
            );
            invalidateInitiativeListsCache(queryClient);
          },
        }
      : {},
  });

  // Log connection status changes
  useEffect(() => {
    if (shouldConnect) {
      console.log("🛢 [CACHE SYNC] Connection state", {
        isConnected: websocketState.isConnected,
        isAuthenticated: websocketState.isAuthenticated,
        connectionError: websocketState.connectionError,
        organizationId,
        projectId,
        initiativeId,
      });
    }
  }, [
    websocketState.isConnected,
    websocketState.isAuthenticated,
    websocketState.connectionError,
    organizationId,
    projectId,
    initiativeId,
    shouldConnect,
  ]);

  return {
    isConnected: websocketState.isConnected,
    isAuthenticated: websocketState.isAuthenticated,
    connectionError: websocketState.connectionError,
  };
};

/**
 * Convenience hook for syncing cache for a specific initiative.
 *
 * @param organizationId - Organization ID
 * @param projectId - Project ID
 * @param initiativeId - Initiative ID
 * @param enabled - Whether to enable sync
 */
export const useInitiativeSpecificCacheSync = ({
  organizationId,
  projectId,
  initiativeId,
  enabled = true,
}: {
  organizationId: string;
  projectId: string;
  initiativeId: string;
  enabled?: boolean;
}) => {
  return useInitiativeCacheSync({
    organizationId,
    projectId,
    initiativeId,
    enabled,
  });
};

/**
 * Convenience hook for syncing cache for all initiatives in an organization.
 *
 * @param organizationId - Organization ID
 * @param projectId - Optional project ID to limit scope
 * @param enabled - Whether to enable sync
 */
export const useOrganizationInitiativesCacheSync = (
  organizationId: string,
  projectId?: string,
  enabled = true
) => {
  return useInitiativeCacheSync({
    organizationId,
    projectId,
    enabled,
  });
};
