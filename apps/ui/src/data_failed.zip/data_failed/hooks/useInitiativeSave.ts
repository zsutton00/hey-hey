import { useState, useCallback } from "react";
import type { Dispatch, SetStateAction } from "react";
import { useUpdateInitiativeContentByConversation } from "../initiatives";
import type { UpdateInitiativeContentByConversationRequest } from "../../api";
import type { LevelType } from "../../components/Initiative/InitiativeEditor";

interface MultiLevelContent {
  description: string;
  details: string;
  acceptanceCriteria: string;
}

type SaveStatus = "draft" | "saving" | "saved" | "submitting" | "sent";
type SaveMode = "silent" | "feedback" | null;

interface MultiLevelSaveStates {
  description: SaveStatus;
  details: SaveStatus;
  acceptanceCriteria: SaveStatus;
}

interface MultiLevelUnsavedChanges {
  description: boolean;
  details: boolean;
  acceptanceCriteria: boolean;
}

export interface UseInitiativeSaveProps {
  organizationId: string;
  projectId: string;
  initiativeId: string;
  conversationId?: string;
  currentLevel: LevelType;
  multiLevelContent: MultiLevelContent;
  lastSavedContent: MultiLevelContent;
  onContentUpdate: Dispatch<SetStateAction<MultiLevelContent>>;
  onLastSavedContentUpdate: Dispatch<SetStateAction<MultiLevelContent>>;
  onUnsavedChangesUpdate: Dispatch<SetStateAction<MultiLevelUnsavedChanges>>;
  onSaveStatesUpdate: Dispatch<SetStateAction<MultiLevelSaveStates>>;
  onError: (error: string) => void;
}

export interface UseInitiativeSaveReturn {
  isSaving: boolean;
  saveMode: SaveMode;
  handleSaveWithoutFeedback: () => Promise<void>;
  handleSaveWithFeedback: () => Promise<void>;
}

// Helper function to map level names to property keys
const getLevelPropertyKey = (level: LevelType): keyof MultiLevelContent => {
  switch (level) {
    case "description":
      return "description";
    case "details":
      return "details";
    case "acceptance_criteria":
      return "acceptanceCriteria";
    default:
      return "description";
  }
};

export const useInitiativeSave = ({
  organizationId,
  projectId,
  initiativeId,
  conversationId,
  currentLevel,
  multiLevelContent,
  // lastSavedContent,
  onContentUpdate,
  onLastSavedContentUpdate,
  onUnsavedChangesUpdate,
  onSaveStatesUpdate,
  onError,
}: UseInitiativeSaveProps): UseInitiativeSaveReturn => {
  const [saveMode, setSaveMode] = useState<SaveMode>(null);

  // Use unified data layer for updating initiative content
  const updateContentMutation = useUpdateInitiativeContentByConversation({
    onSuccess: (data, { data: _payload }) => {
      // Update content based on response
      const responseData = data as {
        updatedInitiative?: {
          description?: string;
          details?: string;
          acceptanceCriteria?: string;
        };
      };
      const updatedInitiative = responseData?.updatedInitiative;

      // Update multi-level content with response
      if (updatedInitiative) {
        onContentUpdate((prev: MultiLevelContent) => ({
          ...prev,
          description: updatedInitiative.description || prev.description,
          details: updatedInitiative.details || prev.details,
          acceptanceCriteria:
            updatedInitiative.acceptanceCriteria || prev.acceptanceCriteria,
        }));

        // Update last saved content for all fields since we saved all of them
        onLastSavedContentUpdate({
          description:
            updatedInitiative.description || multiLevelContent.description,
          details: updatedInitiative.details || multiLevelContent.details,
          acceptanceCriteria:
            updatedInitiative.acceptanceCriteria ||
            multiLevelContent.acceptanceCriteria,
        });
      } else {
        // If no updated content in response, use what we sent
        onLastSavedContentUpdate(multiLevelContent);
      }

      // Mark all fields as saved since we sent all of them
      onUnsavedChangesUpdate({
        description: false,
        details: false,
        acceptanceCriteria: false,
      });

      // Update save states for all sections
      const newSaveStatus = saveMode === "silent" ? "saved" : "sent";
      onSaveStatesUpdate({
        description: newSaveStatus,
        details: newSaveStatus,
        acceptanceCriteria: newSaveStatus,
      });

      // Reset to draft after 2 seconds
      setTimeout(
        () =>
          onSaveStatesUpdate({
            description: "draft",
            details: "draft",
            acceptanceCriteria: "draft",
          }),
        2000
      );

      setSaveMode(null);
    },
    onError: (err: unknown) => {
      onSaveStatesUpdate({
        description: "draft",
        details: "draft",
        acceptanceCriteria: "draft",
      });
      const errorMessage =
        saveMode === "silent"
          ? "Failed to save content"
          : "Failed to save and get feedback";
      onError(err instanceof Error ? err.message : errorMessage);
      setSaveMode(null);
    },
  });

  const performSave = useCallback(
    async (mode: "silent" | "feedback"): Promise<void> => {
      if (!conversationId) {
        return;
      }

      setSaveMode(mode);
      onSaveStatesUpdate((prev: MultiLevelSaveStates) => ({
        ...prev,
        [getLevelPropertyKey(currentLevel)]:
          mode === "silent" ? "saving" : "submitting",
      }));
      onError(""); // Clear any previous errors

      const payload: UpdateInitiativeContentByConversationRequest = {
        description: multiLevelContent.description,
        details: multiLevelContent.details,
        acceptanceCriteria: multiLevelContent.acceptanceCriteria,
        requestFeedback: mode === "feedback",
        feedbackContext:
          mode === "feedback"
            ? "Please provide feedback on the initiative content"
            : undefined,
      };

      updateContentMutation.mutate({
        orgId: organizationId,
        projectId,
        conversationId,
        initiativeId,
        data: payload,
      });
    },
    [
      conversationId,
      currentLevel,
      multiLevelContent,
      organizationId,
      projectId,
      initiativeId,
      onSaveStatesUpdate,
      onError,
      updateContentMutation,
    ]
  );

  const handleSaveWithoutFeedback = useCallback(async (): Promise<void> => {
    await performSave("silent");
  }, [performSave]);

  const handleSaveWithFeedback = useCallback(async (): Promise<void> => {
    await performSave("feedback");
  }, [performSave]);

  return {
    isSaving: updateContentMutation.isPending,
    saveMode,
    handleSaveWithoutFeedback,
    handleSaveWithFeedback,
  };
};
