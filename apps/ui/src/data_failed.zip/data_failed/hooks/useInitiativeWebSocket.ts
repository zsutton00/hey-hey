import { useCallback } from "react";
import { useWebSocketService } from "../../hooks/useWebSocketService";
import { useAuth } from "../../contexts/AuthContext";
import type { InitiativeUpdatedEvent, InitiativeStatusChangedEvent } from "../../api";

export interface UseInitiativeWebSocketConfig {
  projectId: string;
  initiativeId: string;
  organizationId: string;
  userId?: string;
  enabled: boolean;
  onInitiativeUpdated: (event?: InitiativeUpdatedEvent) => void;
  onSystemNotification?: (event: {
    message: string;
    severity: "info" | "warning" | "error";
  }) => void;
}

export const useInitiativeWebSocket = ({
  enabled,
  projectId,
  initiativeId,
  organizationId,
  userId = "anonymous",
  onInitiativeUpdated,
  onSystemNotification,
}: UseInitiativeWebSocketConfig) => {
  const { user } = useAuth();
  const actualUserId = user?.id || userId;


  const handleInitiativeUpdated = useCallback(
    (event: InitiativeUpdatedEvent) => {
      console.log("🔄 [INITIATIVE HOOK] handleInitiativeUpdated called", {
        receivedInitiativeId: event.initiativeId,
        expectedInitiativeId: initiativeId,
        projectId,
        willHandle: event.initiativeId === initiativeId,
        hasInitiativeData: !!event.initiative,
        event,
      });

      // Only handle updates for our initiative
      if (event.initiativeId !== initiativeId) {
        console.log("🔄 [INITIATIVE HOOK] Ignoring event - initiative ID mismatch");
        return;
      }

      console.log("🔄 [INITIATIVE HOOK] Processing initiative update - calling onInitiativeUpdated with event data");
      onInitiativeUpdated(event);
      console.log("🔄 [INITIATIVE HOOK] onInitiativeUpdated callback completed");
    },
    [projectId, initiativeId, onInitiativeUpdated]
  );

  const handleInitiativeCreated = useCallback(
    (event: { aggregateId: string }) => {
      console.log("🔄 Initiative WebSocket: Initiative created", {
        projectId,
        initiativeId,
        event,
      });

      // We might want to handle initiative creation events
      // For now, just log them
    },
    [projectId, initiativeId]
  );

  const handleInitiativeStatusChanged = useCallback(
    (event: InitiativeStatusChangedEvent) => {
      // Only handle updates for our initiative
      if (event.initiativeId !== initiativeId) return;

      console.log("🔄 Initiative WebSocket: Initiative status changed", {
        projectId,
        initiativeId,
        event,
      });

      // Initiative status changes should trigger data reload
      onInitiativeUpdated();
    },
    [projectId, initiativeId, onInitiativeUpdated]
  );

  const handleSystemNotification = useCallback(
    (event: { aggregateId: string }) => {
      // Handle system notifications that might be relevant to the initiative
      console.log("🔔 Initiative WebSocket: System notification", {
        projectId,
        initiativeId,
        event,
      });

      // For now, we don't have access to the notification content in the event
      // so we'll call the callback with a generic message
      onSystemNotification?.({
        message: "System notification received",
        severity: "info",
      });
    },
    [projectId, initiativeId, onSystemNotification]
  );

  // Subscribe to WebSocket events only when enabled
  const shouldConnect =
    enabled && !!projectId && !!initiativeId && !!organizationId;

  const websocketState = useWebSocketService({
    userId: actualUserId,
    projectIds: shouldConnect ? [projectId] : [],
    conversationIds: [], // We're focusing on initiative/project events
    initiativeIds: shouldConnect ? [initiativeId] : [], // Subscribe to initiative channel!
    autoConnect: shouldConnect,
    events: shouldConnect
      ? {
          // Use proper initiative events now that they're available
          onInitiativeCreated: handleInitiativeCreated,
          onInitiativeUpdated: handleInitiativeUpdated,
          onInitiativeStatusChanged: handleInitiativeStatusChanged,
          onSystemNotification: handleSystemNotification,
          // Keep conversation events as backup since initiatives are often
          // updated through conversation interactions
          onConversationUpdated: (_event: { aggregateId: string }) => {
            // For conversation updates, we don't have initiative data, so call without event
            onInitiativeUpdated();
          },
        }
      : {},
  });

  return {
    isConnected: websocketState.isConnected,
    isAuthenticated: websocketState.isAuthenticated,
    connectionError: websocketState.connectionError,
  };
};
