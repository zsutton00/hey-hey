import { useQuery } from "@tanstack/react-query";
import { useMemo } from "react";
import { useProject } from "../../hooks/useProject";
import {
  platformClient,
  conversationsClient,
} from "../../clients/serviceClients";
import { useInitiative } from "./useInitiativeAtomQueries";
import {
  type StartInitiativeRefinementRequest,
  type ConversationResponseDto,
  type InitiativeResponseDto,
  MessageStatus,
} from "../../api";

export interface UseInitiativeDataParams {
  organizationId: string;
  projectId: string;
  initiativeId: string;
}

export interface UseInitiativeDataReturn {
  // Project data
  project: ReturnType<typeof useProject>["data"];
  isProjectLoading: boolean;
  projectError: ReturnType<typeof useProject>["error"];

  // Initiative data
  initiativeData: any; // TODO: Add proper type
  isInitiativeLoading: boolean;
  initiativeError: any;
  refetchInitiative: () => Promise<any>;

  // Refinement data
  refinementData: any; // TODO: Add proper type
  isStartingRefinement: boolean;
  refinementError: any;

  // Conversation data
  conversation: ConversationResponseDto | null;
  isConversationLoading: boolean;
  conversationError: any;
  refetchConversation: () => Promise<any>;

  // Computed states
  isWaitingForFirstMessage: boolean;
  isLoading: boolean;
  hasError: boolean;
}

/**
 * Parameters for conversation initiatives data loading
 */
export interface UseConversationInitiativesParams {
  organizationId: string;
  projectId: string;
  conversationId: string;
}

/**
 * Return type for conversation initiatives hook
 */
export interface UseConversationInitiativesReturn {
  initiatives: InitiativeResponseDto[];
  isLoading: boolean;
  error: any;
  refetch: () => Promise<any>;
}

/**
 * Custom hook that consolidates all data fetching for the InitiativeEditor.
 * Manages project, initiative, refinement, and conversation data with proper
 * dependency chains and loading states.
 */
export const useInitiativeRefinementData = ({
  organizationId,
  projectId,
  initiativeId,
}: UseInitiativeDataParams): UseInitiativeDataReturn => {
  // Load project data
  const {
    data: project,
    isLoading: isProjectLoading,
    error: projectError,
  } = useProject(organizationId, projectId);

  // Load initiative data using unified data layer
  const {
    data: initiativeData,
    isLoading: isInitiativeLoading,
    error: initiativeError,
    refetch: refetchInitiative,
  } = useInitiative(organizationId, initiativeId, {
    enabled: !!organizationId && !!initiativeId,
  });

  // Start initiative refinement to get conversation ID
  const {
    data: refinementData,
    isLoading: isStartingRefinement,
    error: refinementError,
  } = useQuery({
    queryKey: [
      "initiative-refinement-start",
      organizationId,
      initiativeId,
      projectId,
    ],
    queryFn: async () => {
      const request: StartInitiativeRefinementRequest = {
        projectId: projectId,
      };
      const response = await platformClient.startInitiativeRefinement(
        organizationId,
        initiativeId,
        request
      );
      return response.data.data;
    },
    enabled: !!organizationId && !!initiativeId,
    retry: 2,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Load conversation by ID with retry mechanism for message creation
  const {
    data: conversation,
    isLoading: isConversationLoading,
    error: conversationError,
    refetch: refetchConversation,
  } = useQuery<ConversationResponseDto | null>({
    queryKey: [
      "initiative-conversation",
      organizationId,
      projectId,
      refinementData?.conversationId,
    ],
    queryFn: async () => {
      if (!refinementData?.conversationId) {
        return null;
      }
      const response = await platformClient.getConversation(
        organizationId,
        projectId,
        refinementData.conversationId
      );
      return response.data.data as ConversationResponseDto;
    },
    enabled:
      !!organizationId && !!projectId && !!refinementData?.conversationId,
    retry: 2,
    staleTime: 5 * 60 * 1000, // 5 minutes
    // Refetch every 3 seconds if conversation doesn't have a properly initialized first message
    refetchInterval: (query) => {
      const data = query.state.data;

      // If no data yet or no conversation, keep polling
      if (!data) return 3000;

      // If no messages at all, keep polling
      if (!data.messages || data.messages.length === 0) return 3000;

      // If we have messages, check if the first message is properly initialized
      const firstMessage = data.messages[0];

      // Stop polling if:
      // 1. First message has data with response text, OR
      // 2. First message has UI elements to show, OR
      // 3. First message is in a completed state
      const hasResponse = firstMessage.data?.response;
      const hasUIElements =
        firstMessage.data?.uiElements &&
        firstMessage.data.uiElements.length > 0;
      const isCompleted = firstMessage.status === MessageStatus.Completed;

      if (hasResponse || hasUIElements || isCompleted) {
        return false; // Stop polling
      }

      // Keep polling if message exists but isn't fully ready
      return 3000;
    },
    refetchIntervalInBackground: false,
  });

  // Determine if we're waiting for the first message to be properly initialized
  const isWaitingForFirstMessage = useMemo(() => {
    if (!conversation?.messages) return true;
    if (conversation.messages.length === 0) return true;

    const firstMessage = conversation.messages[0];
    const hasResponse = firstMessage.data?.response;
    const hasUIElements =
      firstMessage.data?.uiElements && firstMessage.data.uiElements.length > 0;
    const isCompleted = firstMessage.status === MessageStatus.Completed;

    // We're still waiting if the message exists but isn't ready to display
    return !(hasResponse || hasUIElements || isCompleted);
  }, [conversation?.messages]);

  // Computed loading and error states
  const isLoading =
    isProjectLoading ||
    isInitiativeLoading ||
    isStartingRefinement ||
    isConversationLoading;

  const hasError = !!(
    projectError ||
    initiativeError ||
    refinementError ||
    conversationError
  );

  return {
    // Project data
    project,
    isProjectLoading,
    projectError,

    // Initiative data
    initiativeData,
    isInitiativeLoading,
    initiativeError,
    refetchInitiative,

    // Refinement data
    refinementData,
    isStartingRefinement,
    refinementError,

    // Conversation data
    conversation: conversation ?? null,
    isConversationLoading,
    conversationError,
    refetchConversation,

    // Computed states
    isWaitingForFirstMessage,
    isLoading,
    hasError,
  };
};

/**
 * Query key factory for initiative operations
 */
export const initiativeKeys = {
  all: ["initiative"] as const,
  conversation: (orgId: string, projectId: string, conversationId: string) =>
    [
      ...initiativeKeys.all,
      "conversation",
      orgId,
      projectId,
      conversationId,
    ] as const,
  detail: (orgId: string, initiativeId: string) =>
    [...initiativeKeys.all, "detail", orgId, initiativeId] as const,
};

/**
 * Hook to fetch initiatives for a specific conversation using TanStack Query
 */
export const useConversationInitiatives = ({
  organizationId,
  projectId,
  conversationId,
}: UseConversationInitiativesParams): UseConversationInitiativesReturn => {
  const {
    data: initiatives = [],
    isLoading,
    error,
    refetch,
  } = useQuery<InitiativeResponseDto[], any>({
    queryKey: initiativeKeys.conversation(
      organizationId,
      projectId,
      conversationId
    ),
    queryFn: async () => {
      const response = await conversationsClient.getConversationInitiatives(
        organizationId,
        projectId,
        conversationId
      );
      return response.data.data ?? [];
    },
    enabled: !!organizationId && !!projectId && !!conversationId,
    retry: 2,
    staleTime: 30 * 1000, // 30 seconds - initiatives change frequently during refinement
    refetchOnWindowFocus: false, // Prevent excessive refetching
  });

  return {
    initiatives,
    isLoading,
    error,
    refetch,
  };
};
