/**
 * Initiative Mutation Hooks with Optimistic Updates
 *
 * HTTP mutations use optimistic updates with rollback on error.
 * These are independent from WebSocket events and handle user actions.
 */

import { useMutation, useQueryClient } from "@tanstack/react-query";
import { platformClient } from "../../clients/serviceClients";
import type {
  InitiativeResponseDto,
  CreateInitiativeDto,
  UpdateInitiativeDto,
  UpdateInitiativeContentByConversationRequest,
} from "../../api";
import type {
  CreateInitiativeMutationOptions,
  UpdateInitiativeMutationOptions,
  DeleteInitiativeMutationOptions,
  UpdateInitiativeContentByConversationOptions,
} from "../core/initiatives";

/**
 * Update an existing initiative with optimistic updates and rollback on error.
 */
export const useUpdateInitiative = (
  options: UpdateInitiativeMutationOptions = {}
) => {
  const queryClient = useQueryClient();

  return useMutation({
    // OPTIMISTIC UPDATE: Apply immediately when user makes change
    onMutate: async (variables: {
      orgId: string;
      initiativeId: string;
      data: Partial<InitiativeResponseDto>;
    }) => {
      const queryKey = ["initiative", variables.orgId, variables.initiativeId];
      const listQueryKey = ["initiatives", variables.orgId];

      // Cancel any outgoing refetches
      await queryClient.cancelQueries({ queryKey });
      await queryClient.cancelQueries({ queryKey: listQueryKey });

      // Snapshot the previous values
      const previousData =
        queryClient.getQueryData<InitiativeResponseDto>(queryKey);
      const previousList =
        queryClient.getQueryData<InitiativeResponseDto[]>(listQueryKey);

      // Optimistically update the cache
      if (previousData) {
        const optimisticData = { ...previousData, ...variables.data };

        // Update single entity cache
        queryClient.setQueryData(queryKey, optimisticData);

        // Update list cache
        if (previousList) {
          const optimisticList = previousList.map((item) =>
            item.id === variables.initiativeId ? optimisticData : item
          );
          queryClient.setQueryData(listQueryKey, optimisticList);
        }
      }

      // Return context for rollback
      return { previousData, previousList, queryKey, listQueryKey };
    },

    mutationFn: async (variables) => {
      const response = await platformClient.updateInitiative(
        variables.orgId,
        variables.initiativeId,
        variables.data
      );
      return response.data.data;
    },

    // SUCCESS: Update with actual server response
    onSuccess: (data, variables, context) => {
      if (context) {
        // Update with actual server response (might differ from optimistic)
        queryClient.setQueryData(context.queryKey, data);

        // Update list with server response
        const currentList = queryClient.getQueryData<InitiativeResponseDto[]>(
          context.listQueryKey
        );
        if (currentList) {
          const updatedList = currentList.map((item) =>
            item.id === variables.initiativeId ? data : item
          );
          queryClient.setQueryData(context.listQueryKey, updatedList);
        }
      }
    },

    // ERROR: Rollback optimistic update
    onError: (err, variables, context) => {
      if (context) {
        // Rollback to previous state
        if (context.previousData) {
          queryClient.setQueryData(context.queryKey, context.previousData);
        }
        if (context.previousList) {
          queryClient.setQueryData(context.listQueryKey, context.previousList);
        }

        console.error(
          `HTTP update failed for initiative ${variables.initiativeId}, rolled back optimistic changes:`,
          err
        );
      }
    },
    ...options,
  });
};

/**
 * Create a new initiative with optimistic updates and rollback on error.
 */
export const useCreateInitiative = (
  options: CreateInitiativeMutationOptions = {}
) => {
  const queryClient = useQueryClient();

  return useMutation({
    // OPTIMISTIC CREATE: Add to list immediately
    onMutate: async (variables: {
      orgId: string;
      data: CreateInitiativeDto;
    }) => {
      const listQueryKey = ["initiatives", variables.orgId];
      const tempId = `temp-${Date.now()}`;

      await queryClient.cancelQueries({ queryKey: listQueryKey });

      const previousList =
        queryClient.getQueryData<InitiativeResponseDto[]>(listQueryKey) || [];

      // Add optimistic item to list
      const optimisticItem = {
        id: tempId,
        ...variables.data,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      } as InitiativeResponseDto;

      queryClient.setQueryData(listQueryKey, [...previousList, optimisticItem]);

      return { previousList, tempId, listQueryKey };
    },

    mutationFn: async (variables) => {
      const response = await platformClient.createInitiative(
        variables.orgId,
        variables.data
      );
      return response.data.data;
    },

    onSuccess: (data, variables, context) => {
      if (context) {
        // Replace temp item with real item
        const currentList =
          queryClient.getQueryData<InitiativeResponseDto[]>(
            context.listQueryKey
          ) || [];
        const updatedList = currentList.map((item) =>
          item.id === context.tempId ? data : item
        );
        queryClient.setQueryData(context.listQueryKey, updatedList);
      }
    },

    onError: (err, variables, context) => {
      if (context) {
        // Rollback to previous list
        queryClient.setQueryData(context.listQueryKey, context.previousList);
        console.error(
          `HTTP create failed, rolled back optimistic creation:`,
          err
        );
      }
    },
    ...options,
  });
};

/**
 * Delete an initiative with optimistic updates and rollback on error.
 */
export const useDeleteInitiative = (
  options: DeleteInitiativeMutationOptions = {}
) => {
  const queryClient = useQueryClient();

  return useMutation({
    // OPTIMISTIC DELETE: Remove from list immediately
    onMutate: async (variables: { orgId: string; initiativeId: string }) => {
      const queryKey = ["initiative", variables.orgId, variables.initiativeId];
      const listQueryKey = ["initiatives", variables.orgId];

      await queryClient.cancelQueries({ queryKey });
      await queryClient.cancelQueries({ queryKey: listQueryKey });

      const previousData =
        queryClient.getQueryData<InitiativeResponseDto>(queryKey);
      const previousList =
        queryClient.getQueryData<InitiativeResponseDto[]>(listQueryKey) || [];

      // Remove item from list optimistically
      const optimisticList = previousList.filter(
        (item) => item.id !== variables.initiativeId
      );
      queryClient.setQueryData(listQueryKey, optimisticList);

      // Remove individual item cache
      queryClient.removeQueries({ queryKey });

      return { previousData, previousList, queryKey, listQueryKey };
    },

    mutationFn: async (variables) => {
      await platformClient.removeInitiative(
        variables.orgId,
        variables.initiativeId
      );
    },

    onError: (err, variables, context) => {
      if (context) {
        // Rollback deletion
        if (context.previousList) {
          queryClient.setQueryData(context.listQueryKey, context.previousList);
        }
        if (context.previousData) {
          queryClient.setQueryData(context.queryKey, context.previousData);
        }

        console.error(
          `HTTP delete failed for initiative ${variables.initiativeId}, rolled back optimistic deletion:`,
          err
        );
      }
    },
    ...options,
  });
};

/**
 * Update initiative content via conversation with cache invalidation.
 * Used for feedback requests and conversation-based content updates.
 *
 * Note: This maintains the existing implementation as it's not mentioned in the migration plan.
 */
export const useUpdateInitiativeContentByConversation = (
  options: UpdateInitiativeContentByConversationOptions = {}
) => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      orgId,
      projectId,
      conversationId,
      initiativeId,
      data,
    }: {
      orgId: string;
      projectId: string;
      conversationId: string;
      initiativeId: string;
      data: UpdateInitiativeContentByConversationRequest;
    }) => {
      const response =
        await platformClient.updateInitiativeContentByConversation(
          orgId,
          projectId,
          conversationId,
          initiativeId,
          data
        );
      return response.data;
    },
    onSuccess: (_, { orgId, initiativeId }) => {
      // Invalidate initiative cache since content was updated
      queryClient.invalidateQueries({
        queryKey: ["initiative", orgId, initiativeId],
      });

      // Also invalidate conversation cache as it likely changed
      queryClient.invalidateQueries({
        queryKey: ["conversation"],
        exact: false,
      });
    },
    ...options,
  });
};
