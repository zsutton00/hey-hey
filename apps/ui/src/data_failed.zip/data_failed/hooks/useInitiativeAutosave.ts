import { useState, useCallback, useRef, useEffect } from "react";
import type { AutosaveInitiativeDto } from "../../api";
import { platformClient } from "../../clients/serviceClients";

interface MultiLevelContent {
  description: string;
  details: string;
  acceptanceCriteria: string;
}

type AutosaveStatus = "idle" | "saving" | "saved" | "error";

export interface UseInitiativeAutosaveProps {
  organizationId: string;
  initiativeId: string;
  content: MultiLevelContent;
  enabled?: boolean;
  debounceMs?: number;
  onError?: (error: string) => void;
}

export interface UseInitiativeAutosaveReturn {
  autosaveStatus: AutosaveStatus;
  isAutosaving: boolean;
  lastSavedAt: Date | null;
  triggerManualSave: () => Promise<void>;
}

export const useInitiativeAutosave = ({
  organizationId,
  initiativeId,
  content,
  enabled = true,
  debounceMs = 2000, // 2 second debounce
  onError,
}: UseInitiativeAutosaveProps): UseInitiativeAutosaveReturn => {
  const [autosaveStatus, setAutosaveStatus] = useState<AutosaveStatus>("idle");
  const [lastSavedAt, setLastSavedAt] = useState<Date | null>(null);

  // Refs to track debounce and last saved content
  const debounceTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const lastSavedContentRef = useRef<MultiLevelContent>({
    description: "",
    details: "",
    acceptanceCriteria: "",
  });
  const isSavingRef = useRef(false);
  const enabledAtRef = useRef<Date | null>(null);
  const delayAfterEnabledMs = 1000; // 1 second delay after enabled turns true

  // Check if content has actually changed
  const hasContentChanged = useCallback(
    (newContent: MultiLevelContent): boolean => {
      const lastSaved = lastSavedContentRef.current;
      return (
        newContent.description !== lastSaved.description ||
        newContent.details !== lastSaved.details ||
        newContent.acceptanceCriteria !== lastSaved.acceptanceCriteria
      );
    },
    []
  );

  // Perform the actual autosave
  const performAutosave = useCallback(
    async (contentToSave: MultiLevelContent): Promise<void> => {
      if (isSavingRef.current || !enabled) {
        return;
      }

      try {
        isSavingRef.current = true;
        setAutosaveStatus("saving");

        const payload: AutosaveInitiativeDto = {
          description: contentToSave.description || undefined,
          details: contentToSave.details || undefined,
          acceptanceCriteria: contentToSave.acceptanceCriteria || undefined,
        };

        // Only include fields that have content to avoid clearing empty fields
        const filteredPayload: AutosaveInitiativeDto = {};
        if (payload.description?.trim()) {
          filteredPayload.description = payload.description;
        }
        if (payload.details?.trim()) {
          filteredPayload.details = payload.details;
        }
        if (payload.acceptanceCriteria?.trim()) {
          filteredPayload.acceptanceCriteria = payload.acceptanceCriteria;
        }

        await platformClient.autosaveInitiative(
          organizationId,
          initiativeId,
          filteredPayload
        );

        // Update the last saved content
        lastSavedContentRef.current = { ...contentToSave };
        setLastSavedAt(new Date());
        setAutosaveStatus("saved");

        // Keep the "saved" status visible - don't auto-hide it
      } catch (err) {
        console.error("Autosave failed:", err);
        setAutosaveStatus("error");
        onError?.(err instanceof Error ? err.message : "Autosave failed");

        // Reset to idle after 3 seconds on error
        setTimeout(() => {
          setAutosaveStatus("idle");
        }, 3000);
      } finally {
        isSavingRef.current = false;
      }
    },
    [organizationId, initiativeId, enabled, onError]
  );

  // Track when enabled becomes true
  useEffect(() => {
    if (enabled && !enabledAtRef.current) {
      enabledAtRef.current = new Date();
    } else if (!enabled) {
      enabledAtRef.current = null;
    }
  }, [enabled]);

  // Check if enough time has passed since enabled became true
  const isReadyForAutosave = useCallback((): boolean => {
    if (!enabled || !enabledAtRef.current) {
      return false;
    }
    
    const timeSinceEnabled = Date.now() - enabledAtRef.current.getTime();
    return timeSinceEnabled >= delayAfterEnabledMs;
  }, [enabled, delayAfterEnabledMs]);

  // Debounced autosave effect
  useEffect(() => {
    // Skip if not enabled
    if (!enabled) {
      return;
    }

    // Skip if content hasn't actually changed
    if (!hasContentChanged(content)) {
      return;
    }

    // Skip if not enough time has passed since enabled became true
    // This prevents autosave on initial data load
    if (!isReadyForAutosave()) {
      return;
    }

    // If we were previously saved and now content changed, reset status to idle
    if (autosaveStatus === "saved") {
      setAutosaveStatus("idle");
    }

    // Clear existing timeout
    if (debounceTimeoutRef.current) {
      clearTimeout(debounceTimeoutRef.current);
    }

    // Set new timeout for debounced save
    debounceTimeoutRef.current = setTimeout(() => {
      performAutosave(content);
    }, debounceMs);

    // Cleanup function
    return () => {
      if (debounceTimeoutRef.current) {
        clearTimeout(debounceTimeoutRef.current);
      }
    };
  }, [
    content,
    enabled,
    debounceMs,
    hasContentChanged,
    performAutosave,
    autosaveStatus,
    isReadyForAutosave,
  ]);

  // Manual save trigger
  const triggerManualSave = useCallback(async (): Promise<void> => {
    if (debounceTimeoutRef.current) {
      clearTimeout(debounceTimeoutRef.current);
      debounceTimeoutRef.current = null;
    }
    await performAutosave(content);
  }, [content, performAutosave]);

  // Initialize last saved content on mount
  useEffect(() => {
    lastSavedContentRef.current = { ...content };
  }, []); // Only run on mount

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (debounceTimeoutRef.current) {
        clearTimeout(debounceTimeoutRef.current);
      }
    };
  }, []);

  return {
    autosaveStatus,
    isAutosaving: autosaveStatus === "saving",
    lastSavedAt,
    triggerManualSave,
  };
};
