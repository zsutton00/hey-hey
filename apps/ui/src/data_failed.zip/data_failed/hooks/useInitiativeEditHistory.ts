import { useQuery } from "@tanstack/react-query";
import { platformClient } from "../../clients/serviceClients";
import type { EditHistoryEntryDto } from "../../utils/textDiff";

export interface UseInitiativeEditHistoryParams {
  organizationId: string;
  initiativeId: string;
  enabled?: boolean;
}

export interface UseInitiativeEditHistoryReturn {
  editHistory: EditHistoryEntryDto[];
  isLoading: boolean;
  error: unknown;
  refetch: () => Promise<unknown>;
}

/**
 * Custom hook for fetching initiative edit history
 * Used to show highlighted diffs of system vs user changes
 */
export const useInitiativeEditHistory = ({
  organizationId,
  initiativeId,
  enabled = true,
}: UseInitiativeEditHistoryParams): UseInitiativeEditHistoryReturn => {
  const {
    data: editHistory = [],
    isLoading,
    error,
    refetch,
  } = useQuery({
    queryKey: ["initiative-edit-history", organizationId, initiativeId],
    queryFn: async () => {
      const response = await platformClient.getInitiativeEditHistory(
        organizationId,
        initiativeId
      );
      // Since the API endpoint is a placeholder, return empty array for now
      // When the real API is implemented, this will return response.data.data
      return (response.data.data || []) as EditHistoryEntryDto[];
    },
    enabled: enabled && !!organizationId && !!initiativeId,
    retry: 2,
    staleTime: 1 * 60 * 1000, // 1 minute - edit history changes frequently
    refetchOnWindowFocus: true, // Refetch when user returns to tab
  });

  return {
    editHistory,
    isLoading,
    error,
    refetch,
  };
};
