/**
 * WebSocket Subscription Manager
 *
 * Provides smart subscription deduplication and centralized WebSocket management.
 * Prevents duplicate subscriptions for the same data resources and provides
 * comprehensive debugging capabilities.
 *
 * Error Handling Strategy:
 * - CRITICAL errors (subscription creation failures): Logged, event-tracked, and thrown
 * - CLEANUP errors (unsubscribe/reset failures): Logged and event-tracked, but NOT thrown
 * - UPDATE errors (config update failures): Logged and event-tracked, but NOT thrown
 *
 * This ensures that critical operations fail fast while non-critical operations
 * continue execution to maintain system stability.
 */

import {
  webSocketService,
  type SubscriptionConfig,
} from "../../services/webSocketService";
import { initiativeAtomFamily, organizationInitiativesAtomFamily } from "../atoms/initiativeAtoms";
import { getDefaultStore } from "jotai";
import type { InitiativeResponseDto } from "../../api";

// WebSocket Event Types
interface InitiativeUpdatedEvent {
  organizationId: string;
  initiativeId: string;
  initiative: InitiativeResponseDto;
  timestamp?: string;
}

interface InitiativeCreatedEvent {
  organizationId: string;
  initiativeId: string;
  initiative: InitiativeResponseDto;
  timestamp?: string;
}

interface InitiativeDeletedEvent {
  organizationId: string;
  initiativeId: string;
  timestamp?: string;
}

export interface SubscriptionStats {
  totalActiveSubscriptions: number;
  uniqueDataSubscriptions: number;
  subscriptionCountByKey: Record<string, number>;
  duplicateSubscriptions: number;
}

export interface WebSocketEvent {
  id: string;
  timestamp: string;
  type:
    | "subscription_created"
    | "subscription_removed"
    | "subscription_updated"
    | "websocket_event"
    | "cache_update";
  data: unknown;
  source: string;
  metadata?: Record<string, unknown>;
}

class WebSocketSubscriptionManager {
  private subscriptionCounts = new Map<string, number>();
  private activeSubscriptions = new Map<string, string>(); // subscriptionKey -> webSocketService subscriptionId
  private subscriptionConfigs = new Map<string, SubscriptionConfig>();
  private eventLog: WebSocketEvent[] = [];
  private maxEventLogSize = 1000;
  private eventIdCounter = 0;

  /**
   * Subscribe to WebSocket events with smart deduplication.
   * Multiple components can subscribe to the same data resource,
   * but only one actual WebSocket subscription will be created.
   */
  subscribe(subscriptionKey: string, config: SubscriptionConfig): () => void {
    const currentCount = this.subscriptionCounts.get(subscriptionKey) || 0;

    if (currentCount === 0) {
      // First subscription for this key - create actual WebSocket subscription
      try {
        const webSocketSubId = webSocketService.subscribe(config);
        this.activeSubscriptions.set(subscriptionKey, webSocketSubId);
        this.subscriptionConfigs.set(subscriptionKey, config);

        this.logEvent({
          type: "subscription_created",
          data: {
            subscriptionKey,
            webSocketSubscriptionId: webSocketSubId,
            config: {
              projectIds: config.projectIds,
              conversationIds: config.conversationIds,
              initiativeIds: config.initiativeIds,
              eventCount: Object.keys(config.events || {}).length,
            },
          },
          source: "SubscriptionManager",
        });

        console.log(
          `🛢 [SUB MANAGER] Created WebSocket subscription for ${subscriptionKey}`,
          {
            webSocketSubId,
            config,
          }
        );
      } catch (error) {
        console.error(
          `🛢 [SUB MANAGER] Failed to create subscription for ${subscriptionKey}:`,
          error
        );

        this.logEvent({
          type: "subscription_created",
          data: { subscriptionKey, error: String(error) },
          source: "SubscriptionManager",
          metadata: { success: false },
        });

        throw error;
      }
    } else {
      this.logEvent({
        type: "subscription_updated",
        data: {
          subscriptionKey,
          newCount: currentCount + 1,
          action: "reference_added",
        },
        source: "SubscriptionManager",
      });

      console.log(
        `🛢 [SUB MANAGER] Reusing existing subscription for ${subscriptionKey} (count: ${
          currentCount + 1
        })`
      );
    }

    this.subscriptionCounts.set(subscriptionKey, currentCount + 1);

    // Return cleanup function
    return () => this.unsubscribe(subscriptionKey);
  }

  /**
   * Unsubscribe from WebSocket events.
   * Only removes the actual WebSocket subscription when the last component unsubscribes.
   */
  private unsubscribe(subscriptionKey: string): void {
    const currentCount = this.subscriptionCounts.get(subscriptionKey) || 0;

    if (currentCount <= 1) {
      // Last subscription - clean up actual WebSocket subscription
      const webSocketSubId = this.activeSubscriptions.get(subscriptionKey);

      if (webSocketSubId) {
        try {
          webSocketService.unsubscribe(webSocketSubId);
          this.activeSubscriptions.delete(subscriptionKey);
          this.subscriptionConfigs.delete(subscriptionKey);

          this.logEvent({
            type: "subscription_removed",
            data: {
              subscriptionKey,
              webSocketSubscriptionId: webSocketSubId,
            },
            source: "SubscriptionManager",
          });

          console.log(
            `🛢 [SUB MANAGER] Cleaned up WebSocket subscription for ${subscriptionKey}`
          );
        } catch (error) {
          console.error(
            `🛢 [SUB MANAGER] Failed to clean up subscription for ${subscriptionKey}:`,
            error
          );

          this.logEvent({
            type: "subscription_removed",
            data: { subscriptionKey, error: String(error) },
            source: "SubscriptionManager",
            metadata: { success: false },
          });

          // Don't throw cleanup errors - log them but continue execution
          // This allows the subscription count to be updated even if WebSocket cleanup fails
        }
      }

      this.subscriptionCounts.delete(subscriptionKey);
    } else {
      this.subscriptionCounts.set(subscriptionKey, currentCount - 1);

      this.logEvent({
        type: "subscription_updated",
        data: {
          subscriptionKey,
          newCount: currentCount - 1,
          action: "reference_removed",
        },
        source: "SubscriptionManager",
      });

      console.log(
        `🛢 [SUB MANAGER] Decremented subscription count for ${subscriptionKey} (now: ${
          currentCount - 1
        })`
      );
    }
  }

  /**
   * Update an existing subscription configuration.
   * Useful when component props change but the subscription key remains the same.
   */
  updateSubscription(
    subscriptionKey: string,
    newConfig: SubscriptionConfig
  ): void {
    const webSocketSubId = this.activeSubscriptions.get(subscriptionKey);

    if (!webSocketSubId) {
      console.warn(
        `🛢 [SUB MANAGER] Cannot update subscription ${subscriptionKey} - not found`
      );
      return;
    }

    try {
      webSocketService.updateSubscription(webSocketSubId, newConfig);
      this.subscriptionConfigs.set(subscriptionKey, newConfig);

      this.logEvent({
        type: "subscription_updated",
        data: {
          subscriptionKey,
          webSocketSubscriptionId: webSocketSubId,
          newConfig: {
            projectIds: newConfig.projectIds,
            conversationIds: newConfig.conversationIds,
            initiativeIds: newConfig.initiativeIds,
            eventCount: Object.keys(newConfig.events || {}).length,
          },
        },
        source: "SubscriptionManager",
      });

      console.log(
        `🛢 [SUB MANAGER] Updated subscription configuration for ${subscriptionKey}`
      );
    } catch (error) {
      console.error(
        `🛢 [SUB MANAGER] Failed to update subscription ${subscriptionKey}:`,
        error
      );

      this.logEvent({
        type: "subscription_updated",
        data: {
          subscriptionKey,
          webSocketSubscriptionId: webSocketSubId,
          error: String(error),
        },
        source: "SubscriptionManager",
        metadata: { success: false },
      });

      // Don't throw update errors - they're non-critical operations
      // The subscription remains active even if config update fails
    }
  }

  /**
   * Log WebSocket events for debugging purposes.
   * External systems can use this to track all WebSocket-related activity.
   */
  logEvent(event: Omit<WebSocketEvent, "id" | "timestamp">): void {
    const fullEvent: WebSocketEvent = {
      id: `ws_event_${++this.eventIdCounter}`,
      timestamp: new Date().toISOString(),
      ...event,
    };

    this.eventLog.push(fullEvent);

    // Keep event log size manageable
    if (this.eventLog.length > this.maxEventLogSize) {
      this.eventLog.splice(0, this.eventLog.length - this.maxEventLogSize);
    }
  }

  /**
   * Get comprehensive statistics about current subscriptions.
   * Useful for debugging and performance monitoring.
   */
  getSubscriptionStats(): SubscriptionStats {
    const totalActiveSubscriptions = Array.from(
      this.subscriptionCounts.values()
    ).reduce((sum, count) => sum + count, 0);

    const uniqueDataSubscriptions = this.activeSubscriptions.size;

    const subscriptionCountByKey = Object.fromEntries(
      Array.from(this.subscriptionCounts.entries())
    );

    const duplicateSubscriptions =
      totalActiveSubscriptions - uniqueDataSubscriptions;

    return {
      totalActiveSubscriptions,
      uniqueDataSubscriptions,
      subscriptionCountByKey,
      duplicateSubscriptions,
    };
  }

  /**
   * Get the complete event log for debugging purposes.
   * Returns events in chronological order (oldest first).
   */
  getEventLog(filterByType?: WebSocketEvent["type"]): WebSocketEvent[] {
    if (!filterByType) {
      return [...this.eventLog];
    }

    return this.eventLog.filter((event) => event.type === filterByType);
  }

  /**
   * Clear only the event log without affecting active subscriptions.
   * Safe alternative to reset() for debugging purposes.
   */
  clearEventLog(): void {
    const clearedEventCount = this.eventLog.length;
    this.eventLog.length = 0;

    // Log the clear action (after clearing to avoid logging the clear event itself infinitely)
    this.logEvent({
      type: "subscription_updated",
      data: {
        action: "event_log_cleared",
        clearedEventCount,
      },
      source: "SubscriptionManager",
    });

    console.log(
      `🛢 [SUB MANAGER] Event log cleared (removed ${clearedEventCount} events)`
    );
  }

  /**
   * Get current active subscriptions with their configurations.
   * Useful for debugging what data is currently being subscribed to.
   */
  getActiveSubscriptions(): Array<{
    subscriptionKey: string;
    webSocketSubscriptionId: string;
    referenceCount: number;
    config: SubscriptionConfig;
  }> {
    return Array.from(this.activeSubscriptions.entries()).map(
      ([key, webSocketSubId]) => ({
        subscriptionKey: key,
        webSocketSubscriptionId: webSocketSubId,
        referenceCount: this.subscriptionCounts.get(key) || 0,
        config: this.subscriptionConfigs.get(key) || {},
      })
    );
  }

  // ============================================================================
  // INITIATIVE EVENT HANDLERS (Use Cache Strategies)
  // ============================================================================

  /**
   * Handle initiative updated events using Jotai atoms with cache strategies
   */
  private handleInitiativeUpdated = (event: InitiativeUpdatedEvent) => {
    const store = getDefaultStore();
    const atom = initiativeAtomFamily({ orgId: event.organizationId, initiativeId: event.initiativeId });
    const listAtom = organizationInitiativesAtomFamily(event.organizationId);

    // WebSocket events use configured cache strategy - atoms handle cache internally
    store.set(atom, event.initiative);
    
    // Update the list atom with the updated initiative
    // Note: We need to pass queryClient, but since this is WebSocket event,
    // the atom will handle the cache strategy internally
    try {
      store.set(listAtom, { action: 'update', data: event.initiative, queryClient: null as any });
    } catch (error) {
      console.warn('Failed to update list atom, will invalidate instead:', error);
    }

    // Log the atomic update (no more manual cache invalidation)
    this.logEvent({
      type: "websocket_event",
      data: {
        eventType: "initiative.updated",
        atomicUpdate: true
      },
      source: "WebSocketManager"
    });

    // NO MORE MANUAL queryClient.invalidateQueries() CALLS!
    // The atoms handle this based on their configured cache strategy
  };

  /**
   * Handle initiative created events using Jotai atoms with cache strategies
   */
  private handleInitiativeCreated = (event: InitiativeCreatedEvent) => {
    const store = getDefaultStore();
    const listAtom = organizationInitiativesAtomFamily(event.organizationId);

    // Add to list using cache strategy
    try {
      store.set(listAtom, { action: 'create', data: event.initiative, queryClient: null as any });
    } catch (error) {
      console.warn('Failed to update list atom for created initiative:', error);
    }

    this.logEvent({
      type: "websocket_event",
      data: { eventType: "initiative.created", atomicUpdate: true },
      source: "WebSocketManager"
    });
  };

  /**
   * Handle initiative deleted events using Jotai atoms with cache strategies
   */
  private handleInitiativeDeleted = (event: InitiativeDeletedEvent) => {
    const store = getDefaultStore();
    const listAtom = organizationInitiativesAtomFamily(event.organizationId);

    // Remove from list using cache strategy
    try {
      store.set(listAtom, { 
        action: 'delete', 
        data: { id: event.initiativeId } as InitiativeResponseDto, 
        queryClient: null as any 
      });
    } catch (error) {
      console.warn('Failed to update list atom for deleted initiative:', error);
    }

    this.logEvent({
      type: "websocket_event",
      data: { eventType: "initiative.deleted", atomicUpdate: true },
      source: "WebSocketManager"
    });
  };

  /**
   * Clear all subscriptions and reset the manager.
   * Useful for testing or when completely reinitializing the WebSocket connection.
   */
  reset(): void {
    // Clean up all active WebSocket subscriptions
    this.activeSubscriptions.forEach((webSocketSubId, subscriptionKey) => {
      try {
        webSocketService.unsubscribe(webSocketSubId);
        console.log(
          `🛢 [SUB MANAGER] Reset: Cleaned up subscription ${subscriptionKey}`
        );
      } catch (error) {
        console.error(
          `🛢 [SUB MANAGER] Reset: Failed to clean up ${subscriptionKey}:`,
          error
        );

        this.logEvent({
          type: "subscription_removed",
          data: {
            subscriptionKey,
            webSocketSubscriptionId: webSocketSubId,
            error: String(error),
          },
          source: "SubscriptionManager",
          metadata: { success: false, isReset: true },
        });

        // Don't throw reset cleanup errors - continue resetting other subscriptions
      }
    });

    this.subscriptionCounts.clear();
    this.activeSubscriptions.clear();
    this.subscriptionConfigs.clear();
    this.eventLog.length = 0;
    this.eventIdCounter = 0;

    this.logEvent({
      type: "subscription_updated",
      data: { action: "manager_reset" },
      source: "SubscriptionManager",
    });

    console.log("🛢 [SUB MANAGER] Manager reset completed");
  }
}

// Export singleton instance
export const subscriptionManager = new WebSocketSubscriptionManager();

// Export class for testing
export { WebSocketSubscriptionManager };
