/**
 * WebSocket Debug System
 *
 * Provides comprehensive debugging utilities for WebSocket subscriptions,
 * events, and cache updates. Enables developers to understand and
 * troubleshoot real-time data flow issues.
 */

import { useEffect, useState } from "react";
import {
  subscriptionManager,
  type WebSocketEvent,
  type SubscriptionStats,
} from "./manager";
import { webSocketService } from "../../services/webSocketService";

export interface WebSocketDebugState {
  events: WebSocketEvent[];
  subscriptionStats: SubscriptionStats;
  connectionState: {
    isConnected: boolean;
    isAuthenticated: boolean;
    connectionError: string | null;
  };
  activeSubscriptions: Array<{
    subscriptionKey: string;
    webSocketSubscriptionId: string;
    referenceCount: number;
    config: {
      projectIds?: string[];
      conversationIds?: string[];
      initiativeIds?: string[];
      eventCount: number;
    };
  }>;
}

export interface WebSocketEventFilter {
  type?: WebSocketEvent["type"];
  source?: string;
  timeRange?: {
    start: Date;
    end: Date;
  };
  search?: string;
}

/**
 * React hook for accessing WebSocket debug information.
 * Provides real-time updates on WebSocket state, events, and subscriptions.
 */
export const useWebSocketDebug = (
  options: {
    updateInterval?: number;
    maxEvents?: number;
    filter?: WebSocketEventFilter;
  } = {}
): WebSocketDebugState & {
  clearEventLog: () => void;
  exportDebugData: () => string;
  getFilteredEvents: (filter: WebSocketEventFilter) => WebSocketEvent[];
} => {
  const { updateInterval = 1000, maxEvents = 100, filter } = options;

  const [debugState, setDebugState] = useState<WebSocketDebugState>(() => ({
    events: [],
    subscriptionStats: {
      totalActiveSubscriptions: 0,
      uniqueDataSubscriptions: 0,
      subscriptionCountByKey: {},
      duplicateSubscriptions: 0,
    },
    connectionState: {
      isConnected: false,
      isAuthenticated: false,
      connectionError: null,
    },
    activeSubscriptions: [],
  }));

  // Update debug state periodically
  useEffect(() => {
    const updateDebugState = () => {
      const events = subscriptionManager.getEventLog();
      const subscriptionStats = subscriptionManager.getSubscriptionStats();
      const connectionState = webSocketService.getState();
      const activeSubscriptions = subscriptionManager.getActiveSubscriptions();

      setDebugState({
        events: events.slice(-maxEvents), // Keep only recent events
        subscriptionStats,
        connectionState,
        activeSubscriptions: activeSubscriptions.map((sub) => ({
          ...sub,
          config: {
            projectIds: sub.config.projectIds,
            conversationIds: sub.config.conversationIds,
            initiativeIds: sub.config.initiativeIds,
            eventCount: Object.keys(sub.config.events || {}).length,
          },
        })),
      });
    };

    // Initial update
    updateDebugState();

    // Set up periodic updates
    const interval = setInterval(updateDebugState, updateInterval);

    return () => clearInterval(interval);
  }, [updateInterval, maxEvents]);

  const clearEventLog = () => {
    // Clear only the event log without affecting active subscriptions
    subscriptionManager.clearEventLog();
  };

  const getFilteredEvents = (
    eventFilter: WebSocketEventFilter
  ): WebSocketEvent[] => {
    let filteredEvents = debugState.events;

    if (eventFilter.type) {
      filteredEvents = filteredEvents.filter(
        (event) => event.type === eventFilter.type
      );
    }

    if (eventFilter.source) {
      filteredEvents = filteredEvents.filter((event) =>
        event.source.toLowerCase().includes(eventFilter.source!.toLowerCase())
      );
    }

    if (eventFilter.timeRange) {
      filteredEvents = filteredEvents.filter((event) => {
        const eventTime = new Date(event.timestamp);
        return (
          eventTime >= eventFilter.timeRange!.start &&
          eventTime <= eventFilter.timeRange!.end
        );
      });
    }

    if (eventFilter.search) {
      const searchLower = eventFilter.search.toLowerCase();
      filteredEvents = filteredEvents.filter(
        (event) =>
          JSON.stringify(event.data).toLowerCase().includes(searchLower) ||
          event.source.toLowerCase().includes(searchLower) ||
          event.type.toLowerCase().includes(searchLower)
      );
    }

    return filteredEvents;
  };

  const exportDebugData = (): string => {
    const debugData = {
      timestamp: new Date().toISOString(),
      connectionState: debugState.connectionState,
      subscriptionStats: debugState.subscriptionStats,
      activeSubscriptions: debugState.activeSubscriptions,
      events: debugState.events,
      systemInfo: {
        userAgent: navigator.userAgent,
        url: window.location.href,
        websocketServiceState: webSocketService.getState(),
      },
    };

    return JSON.stringify(debugData, null, 2);
  };

  return {
    ...debugState,
    events: filter ? getFilteredEvents(filter) : debugState.events,
    clearEventLog,
    exportDebugData,
    getFilteredEvents,
  };
};

/**
 * Utility class for programmatic WebSocket debugging.
 * Useful for automated testing and monitoring.
 */
export class WebSocketDebugger {
  private eventListeners = new Set<(event: WebSocketEvent) => void>();
  private isMonitoring = false;
  private monitoringInterval: NodeJS.Timeout | null = null;

  /**
   * Start monitoring WebSocket events and call listeners.
   */
  startMonitoring(interval = 1000): void {
    if (this.isMonitoring) {
      console.warn("🔍 [WS DEBUG] Already monitoring");
      return;
    }

    this.isMonitoring = true;
    let lastEventCount = 0;

    this.monitoringInterval = setInterval(() => {
      const events = subscriptionManager.getEventLog();
      const newEvents = events.slice(lastEventCount);

      if (newEvents.length > 0) {
        newEvents.forEach((event) => {
          this.eventListeners.forEach((listener) => {
            try {
              listener(event);
            } catch (error) {
              console.error("🔍 [WS DEBUG] Error in event listener:", error);
            }
          });
        });

        lastEventCount = events.length;
      }
    }, interval);

    console.log("🔍 [WS DEBUG] Started monitoring");
  }

  /**
   * Stop monitoring WebSocket events.
   */
  stopMonitoring(): void {
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
      this.monitoringInterval = null;
    }

    this.isMonitoring = false;
    console.log("🔍 [WS DEBUG] Stopped monitoring");
  }

  /**
   * Add an event listener for WebSocket events.
   */
  addEventListener(listener: (event: WebSocketEvent) => void): () => void {
    this.eventListeners.add(listener);

    return () => {
      this.eventListeners.delete(listener);
    };
  }

  /**
   * Get current WebSocket statistics.
   */
  getStats(): {
    subscriptionStats: SubscriptionStats;
    connectionState: ReturnType<typeof webSocketService.getState>;
    eventCounts: Record<WebSocketEvent["type"], number>;
    recentErrors: WebSocketEvent[];
  } {
    const events = subscriptionManager.getEventLog();
    const subscriptionStats = subscriptionManager.getSubscriptionStats();
    const connectionState = webSocketService.getState();

    // Count events by type
    const eventCounts = events.reduce((counts, event) => {
      counts[event.type] = (counts[event.type] || 0) + 1;
      return counts;
    }, {} as Record<WebSocketEvent["type"], number>);

    // Find recent errors (events with error metadata)
    const recentErrors = events
      .filter(
        (event) =>
          event.metadata?.success === false ||
          JSON.stringify(event.data).includes("error")
      )
      .slice(-10); // Last 10 errors

    return {
      subscriptionStats,
      connectionState,
      eventCounts,
      recentErrors,
    };
  }

  /**
   * Generate a debug report for support purposes.
   */
  generateReport(): string {
    const stats = this.getStats();
    const events = subscriptionManager.getEventLog();
    const activeSubscriptions = subscriptionManager.getActiveSubscriptions();

    const report = {
      timestamp: new Date().toISOString(),
      summary: {
        connectionHealthy:
          stats.connectionState.isConnected &&
          stats.connectionState.isAuthenticated,
        totalEvents: events.length,
        activeSubscriptions: stats.subscriptionStats.uniqueDataSubscriptions,
        recentErrorCount: stats.recentErrors.length,
      },
      connectionState: stats.connectionState,
      subscriptionStats: stats.subscriptionStats,
      eventCounts: stats.eventCounts,
      recentErrors: stats.recentErrors,
      activeSubscriptions: activeSubscriptions.map((sub) => ({
        key: sub.subscriptionKey,
        referenceCount: sub.referenceCount,
        subscribedTo: {
          projects: sub.config.projectIds?.length || 0,
          conversations: sub.config.conversationIds?.length || 0,
          initiatives: sub.config.initiativeIds?.length || 0,
        },
      })),
      systemInfo: {
        userAgent: navigator.userAgent,
        url: window.location.href,
        timestamp: new Date().toISOString(),
      },
    };

    return JSON.stringify(report, null, 2);
  }
}

// Export singleton debugger instance
export const webSocketDebugger = new WebSocketDebugger();

/**
 * Development helper: Auto-start debugging in development mode.
 */
if (process.env.NODE_ENV === "development") {
  // Auto-start monitoring in development
  webSocketDebugger.startMonitoring();

  // Add global access for debugging in browser console
  (window as unknown as { wsDebug?: WebSocketDebugger }).wsDebug =
    webSocketDebugger;

  console.log(
    "🛢 [WS DEBUG] Development mode: WebSocket debugging enabled. Use window.wsDebug to access debugger."
  );
}
