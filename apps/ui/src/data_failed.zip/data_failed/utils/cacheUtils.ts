/**
 * Initiative Cache Management Utilities
 *
 * Utility functions for managing TanStack Query cache invalidation
 * and WebSocket integration for initiatives. Includes advanced conflict
 * resolution for handling race conditions between local mutations and
 * WebSocket updates.
 */

import type { QueryClient } from "@tanstack/react-query";
import { initiativeKeys } from "../core/initiatives";
import type { InitiativeResponseDto } from "../../api";
import { subscriptionManager } from "../websockets/manager";

// ============================================================================
// CACHE UTILITIES
// ============================================================================

/**
 * Invalidate all initiative-related cache entries.
 * Useful for WebSocket integration and global cache refresh.
 */
export const invalidateAllInitiativeCache = (
  queryClient: QueryClient,
  options: { refetchType?: "active" | "inactive" | "all" | "none" } = {}
) => {
  const { refetchType = "active" } = options;

  return queryClient.invalidateQueries({
    queryKey: initiativeKeys.all,
    exact: false,
    refetchType,
  });
};

/**
 * Invalidate cache for a specific initiative.
 * Useful for WebSocket events targeting specific initiatives.
 */
export const invalidateInitiativeCache = (
  queryClient: QueryClient,
  orgId: string,
  initiativeId: string,
  options: { refetchType?: "active" | "inactive" | "all" | "none" } = {}
) => {
  const { refetchType = "active" } = options;

  return Promise.all([
    // Invalidate the specific initiative
    queryClient.invalidateQueries({
      queryKey: initiativeKeys.detail(orgId, initiativeId),
      refetchType,
    }),
    // Invalidate lists that might contain this initiative
    queryClient.invalidateQueries({
      queryKey: initiativeKeys.lists(),
      exact: false,
      refetchType,
    }),
  ]);
};

/**
 * Invalidate only initiative list caches.
 * Useful for creation/deletion events.
 */
export const invalidateInitiativeListsCache = (
  queryClient: QueryClient,
  options: { refetchType?: "active" | "inactive" | "all" | "none" } = {}
) => {
  const { refetchType = "active" } = options;

  return queryClient.invalidateQueries({
    queryKey: initiativeKeys.lists(),
    exact: false,
    refetchType,
  });
};

// ============================================================================
// WEBSOCKET INTEGRATION HELPERS WITH CONFLICT RESOLUTION
// ============================================================================

export interface ConflictResolutionOptions {
  eventTimestamp?: string;
  forceUpdate?: boolean;
  preserveOptimisticFields?: string[];
  source?: string;
  /** Control whether to refetch after invalidation. Default: 'none' for WebSocket updates */
  refetchType?: "active" | "inactive" | "all" | "none";
}

/**
 * Enhanced WebSocket update handler with comprehensive conflict resolution.
 * Handles race conditions between local mutations and WebSocket events.
 */
export const handleInitiativeWebSocketUpdateWithConflictResolution = (
  queryClient: QueryClient,
  orgId: string,
  initiativeId: string,
  updatedData?: Partial<InitiativeResponseDto>,
  options: ConflictResolutionOptions = {}
) => {
  const {
    eventTimestamp,
    forceUpdate = false,
    preserveOptimisticFields = [],
    source = "WebSocket",
    refetchType = "none", // Default to 'none' for WebSocket updates to prevent immediate refetch
  } = options;

  const queryKey = initiativeKeys.detail(orgId, initiativeId);
  const currentData = queryClient.getQueryData<InitiativeResponseDto>(queryKey);

  subscriptionManager.logEvent({
    type: "cache_update",
    data: {
      initiativeId,
      orgId,
      hasUpdatedData: !!updatedData,
      hasCurrentData: !!currentData,
      eventTimestamp,
      source,
      updatedFields: updatedData ? Object.keys(updatedData) : [],
    },
    source: "CacheUtils",
  });

  if (!updatedData || !currentData) {
    console.log(
      `🛢 [CACHE] Simple invalidation for ${initiativeId} - no data to merge`
    );
    return invalidateInitiativeCache(queryClient, orgId, initiativeId, {
      refetchType,
    });
  }

  // 1. Timestamp-based conflict resolution
  if (eventTimestamp && currentData.updatedAt && !forceUpdate) {
    const eventTime = new Date(eventTimestamp);
    const currentTime = new Date(currentData.updatedAt);

    if (currentTime > eventTime) {
      console.log(
        `🚫 [CACHE] Ignoring stale WebSocket update for ${initiativeId}`,
        {
          current: currentTime.toISOString(),
          event: eventTime.toISOString(),
          source,
        }
      );

      subscriptionManager.logEvent({
        type: "cache_update",
        data: {
          initiativeId,
          action: "ignored_stale_update",
          currentTime,
          eventTime,
        },
        source: "CacheUtils",
        metadata: { ignored: true },
      });

      return Promise.resolve();
    }
  }

  // 2. Check for ongoing mutations that might conflict
  const pendingUpdateResult = deferUpdateDuringMutations(
    queryClient,
    [...queryKey],
    initiativeId,
    () =>
      handleInitiativeWebSocketUpdateWithConflictResolution(
        queryClient,
        orgId,
        initiativeId,
        updatedData,
        { ...options, forceUpdate: true }
      )
  );

  if (pendingUpdateResult) {
    return pendingUpdateResult;
  }

  // 3. Apply update with optimistic preservation
  const mergedData = mergeWithOptimisticUpdates(
    currentData,
    updatedData,
    preserveOptimisticFields
  );

  queryClient.setQueryData(queryKey, mergedData);

  console.log(`🔄 [CACHE] Applied WebSocket update for ${initiativeId}`, {
    updatedFields: Object.keys(updatedData),
    preservedFields: preserveOptimisticFields,
    source,
    mergedData,
  });

  subscriptionManager.logEvent({
    type: "cache_update",
    data: {
      initiativeId,
      action: "update_applied",
      updatedFields: Object.keys(updatedData),
      preservedFields: preserveOptimisticFields,
    },
    source: "CacheUtils",
    metadata: { success: true },
  });

  // Mark as stale but don't refetch immediately for WebSocket updates
  // This allows the UI to show the immediate update while marking data as potentially stale
  return invalidateInitiativeCache(queryClient, orgId, initiativeId, {
    refetchType,
  });
};

/**
 * Check for pending mutations and defer WebSocket updates if necessary.
 * Returns a Promise if update was deferred, null if safe to proceed.
 */
export const deferUpdateDuringMutations = (
  queryClient: QueryClient,
  _queryKey: unknown[],
  initiativeId: string,
  deferredUpdate: () => Promise<unknown>
): Promise<unknown> | null => {
  const mutationCache = queryClient.getMutationCache();
  const pendingMutations = mutationCache.getAll().filter((mutation) => {
    // Check if mutation is loading and related to this initiative
    if (mutation.state.status !== "pending") return false;

    // Check if mutation key includes the initiative ID
    const mutationKeyStr = JSON.stringify(mutation.options.mutationKey || []);
    return mutationKeyStr.includes(initiativeId);
  });

  if (pendingMutations.length > 0) {
    console.log(
      `🛢 [CACHE] Deferring WebSocket update for ${initiativeId} due to ${pendingMutations.length} pending mutations`
    );

    subscriptionManager.logEvent({
      type: "cache_update",
      data: {
        initiativeId,
        action: "deferred_for_mutations",
        pendingMutationCount: pendingMutations.length,
      },
      source: "CacheUtils",
      metadata: { deferred: true },
    });

    // Implement proper mutation observation with safety timeout
    return new Promise((resolve) => {
      const startTime = Date.now();
      const maxWaitTime = 5000; // 5 second safety timeout

      const checkMutations = () => {
        const elapsed = Date.now() - startTime;

        if (elapsed > maxWaitTime) {
          console.warn(
            `🛢 [CACHE] Timeout waiting for mutations to complete for ${initiativeId}, applying update anyway`
          );
          resolve(deferredUpdate());
          return;
        }

        const mutationCache = queryClient.getMutationCache();
        const stillPendingMutations = mutationCache
          .getAll()
          .filter((mutation) => {
            if (mutation.state.status !== "pending") return false;
            const mutationKeyStr = JSON.stringify(
              mutation.options.mutationKey || []
            );
            return mutationKeyStr.includes(initiativeId);
          });

        if (stillPendingMutations.length === 0) {
          console.log(
            `🛢 [CACHE] All mutations completed, applying deferred update for ${initiativeId} (waited ${elapsed}ms)`
          );
          resolve(deferredUpdate());
        } else {
          console.log(
            `🛢 [CACHE] Still waiting for ${stillPendingMutations.length} mutations to complete for ${initiativeId} (${elapsed}ms)`
          );
          // Check again in 100ms
          setTimeout(checkMutations, 100);
        }
      };

      // Start checking after brief initial delay
      setTimeout(checkMutations, 50);
    });
  }

  return null;
};

/**
 * Merge WebSocket data with current cache data, preserving optimistic updates.
 */
export const mergeWithOptimisticUpdates = (
  currentData: InitiativeResponseDto,
  updatedData: Partial<InitiativeResponseDto>,
  preserveOptimisticFields: string[] = []
): InitiativeResponseDto => {
  // Start with current data merged with WebSocket data
  const mergedData = { ...currentData, ...updatedData };

  // Preserve specific fields if they were optimistically updated
  // This is indicated by a special marker or field comparison
  if (
    preserveOptimisticFields.length > 0 &&
    (currentData as unknown as { isOptimistic?: boolean }).isOptimistic
  ) {
    preserveOptimisticFields.forEach((field) => {
      if (field in currentData) {
        (mergedData as unknown as Record<string, unknown>)[field] = (
          currentData as unknown as Record<string, unknown>
        )[field];
      }
    });

    console.log(
      `🛢 [CACHE] Preserved optimistic fields: ${preserveOptimisticFields.join(
        ", "
      )}`
    );
  }

  // Remove optimistic markers if present
  delete (mergedData as unknown as { isOptimistic?: boolean }).isOptimistic;

  return mergedData;
};

/**
 * Legacy function - maintained for backwards compatibility.
 * Use handleInitiativeWebSocketUpdateWithConflictResolution for new code.
 */
export const handleInitiativeWebSocketUpdate = (
  queryClient: QueryClient,
  orgId: string,
  initiativeId: string,
  updatedData?: Partial<InitiativeResponseDto>
) => {
  return handleInitiativeWebSocketUpdateWithConflictResolution(
    queryClient,
    orgId,
    initiativeId,
    updatedData,
    { source: "WebSocket_Legacy" }
  );
};

/**
 * Handle WebSocket initiative creation events.
 */
export const handleInitiativeWebSocketCreation = (
  queryClient: QueryClient,
  newInitiative?: InitiativeResponseDto
) => {
  if (newInitiative) {
    // Add new initiative to cache
    queryClient.setQueryData(
      initiativeKeys.detail(newInitiative.organizationId, newInitiative.id),
      newInitiative
    );
  }

  // Invalidate lists to show new initiative (refetch immediately for creation)
  return invalidateInitiativeListsCache(queryClient, { refetchType: "active" });
};

/**
 * Handle WebSocket initiative deletion events.
 */
export const handleInitiativeWebSocketDeletion = (
  queryClient: QueryClient,
  orgId: string,
  initiativeId: string
) => {
  // Remove from cache
  queryClient.removeQueries({
    queryKey: initiativeKeys.detail(orgId, initiativeId),
  });

  // Invalidate lists (refetch immediately for deletion)
  return invalidateInitiativeListsCache(queryClient, { refetchType: "active" });
};
