/**
 * Core Initiative Data Layer - Query Keys and Types
 *
 * Centralizes query key factory and type definitions for initiatives.
 */

import type {
  UseQueryOptions,
  UseMutationOptions,
} from "@tanstack/react-query";
import type {
  InitiativeResponseDto,
  CreateInitiativeDto,
  UpdateInitiativeDto,
  ConversationResponseDto,
  UpdateInitiativeContentByConversationRequest,
} from "../../api";

// ============================================================================
// QUERY KEY FACTORY
// ============================================================================

/**
 * Hierarchical query key factory for consistent cache management.
 * Enables targeted cache invalidation and efficient cache operations.
 */
export const initiativeKeys = {
  all: ["initiatives"] as const,
  lists: () => [...initiativeKeys.all, "list"] as const,
  list: (orgId: string, filters?: Record<string, unknown>) =>
    [...initiativeKeys.lists(), orgId, ...(filters ? [filters] : [])] as const,
  details: () => [...initiativeKeys.all, "detail"] as const,
  detail: (orgId: string, initiativeId: string) =>
    [...initiativeKeys.details(), orgId, initiativeId] as const,
  conversations: (orgId: string, initiativeId: string) =>
    [...initiativeKeys.detail(orgId, initiativeId), "conversations"] as const,
  refinement: (orgId: string, initiativeId: string) =>
    [...initiativeKeys.detail(orgId, initiativeId), "refinement"] as const,
};

// ============================================================================
// TYPES
// ============================================================================

export interface UseInitiativeOptions
  extends Omit<UseQueryOptions<InitiativeResponseDto>, "queryKey" | "queryFn"> {
  enabled?: boolean;
}

export interface UseInitiativesOptions
  extends Omit<
    UseQueryOptions<InitiativeResponseDto[]>,
    "queryKey" | "queryFn"
  > {
  enabled?: boolean;
  filters?: Record<string, unknown>;
}

export interface UseInitiativeConversationsOptions
  extends Omit<
    UseQueryOptions<ConversationResponseDto>,
    "queryKey" | "queryFn"
  > {
  enabled?: boolean;
}

export type CreateInitiativeMutationOptions = Omit<
  UseMutationOptions<
    InitiativeResponseDto,
    Error,
    {
      orgId: string;
      data: CreateInitiativeDto;
    }
  >,
  "mutationFn"
>;

export type UpdateInitiativeMutationOptions = Omit<
  UseMutationOptions<
    InitiativeResponseDto,
    Error,
    {
      orgId: string;
      initiativeId: string;
      data: UpdateInitiativeDto;
    }
  >,
  "mutationFn"
>;

export type DeleteInitiativeMutationOptions = Omit<
  UseMutationOptions<
    void,
    Error,
    {
      orgId: string;
      initiativeId: string;
    }
  >,
  "mutationFn"
>;

export type UpdateInitiativeContentByConversationOptions = Omit<
  UseMutationOptions<
    unknown,
    Error,
    {
      orgId: string;
      projectId: string;
      conversationId: string;
      initiativeId: string;
      data: UpdateInitiativeContentByConversationRequest;
    }
  >,
  "mutationFn"
>;
